<template>
  <div class="share"></div>
</template>

<script>
export default {
  name: "share"
};
</script>

<style lang="scss" scoped>
.share {
  width: 750px;
  height: 1334px;
  background: url("../../assets/images/catFishing/share.png") no-repeat center
    center;
  background-size: 100%;
}
</style>