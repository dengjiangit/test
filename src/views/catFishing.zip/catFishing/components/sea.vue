<template>
  <div class="seaCompBox"></div>
</template>

<script>
export default {
  name: "sea"
};
</script>

<style lang="scss" scoped>
.seaCompBox {
  width: 750px;
  height: 706px;
  background: url("../../../../static/images/Fish/sea/sea1.png") no-repeat 0 0;
  background-size: 100%;
  animation: seaBoxAnimation 3.1s ease-out infinite;
}
@keyframes seaBoxAnimation {
  0% {
    background: url("../../../../static/images/Fish/sea/sea1.png") no-repeat 0 0;
    background-size: 100%;
  }
  2% {
    background: url("../../../../static/images/Fish/sea/sea2.png") no-repeat 0 0;
    background-size: 100%;
  }
  4% {
    background: url("../../../../static/images/Fish/sea/sea3.png") no-repeat 0 0;
    background-size: 100%;
  }
  6% {
    background: url("../../../../static/images/Fish/sea/sea4.png") no-repeat 0 0;
    background-size: 100%;
  }
  8% {
    background: url("../../../../static/images/Fish/sea/sea5.png") no-repeat 0 0;
    background-size: 100%;
  }
  10% {
    background: url("../../../../static/images/Fish/sea/sea6.png") no-repeat 0 0;
    background-size: 100%;
  }
  12% {
    background: url("../../../../static/images/Fish/sea/sea7.png") no-repeat 0 0;
    background-size: 100%;
  }
  14% {
    background: url("../../../../static/images/Fish/sea/sea8.png") no-repeat 0 0;
    background-size: 100%;
  }
  16% {
    background: url("../../../../static/images/Fish/sea/sea9.png") no-repeat 0 0;
    background-size: 100%;
  }
  18% {
    background: url("../../../../static/images/Fish/sea/sea10.png") no-repeat 0
      0;
    background-size: 100%;
  }
  20% {
    background: url("../../../../static/images/Fish/sea/sea11.png") no-repeat 0
      0;
    background-size: 100%;
  }
  22% {
    background: url("../../../../static/images/Fish/sea/sea12.png") no-repeat 0
      0;
    background-size: 100%;
  }
  24% {
    background: url("../../../../static/images/Fish/sea/sea13.png") no-repeat 0
      0;
    background-size: 100%;
  }
  26% {
    background: url("../../../../static/images/Fish/sea/sea14.png") no-repeat 0
      0;
    background-size: 100%;
  }
  28% {
    background: url("../../../../static/images/Fish/sea/sea15.png") no-repeat 0
      0;
    background-size: 100%;
  }
  30% {
    background: url("../../../../static/images/Fish/sea/sea16.png") no-repeat 0
      0;
    background-size: 100%;
  }
  32% {
    background: url("../../../../static/images/Fish/sea/sea17.png") no-repeat 0
      0;
    background-size: 100%;
  }
  34% {
    background: url("../../../../static/images/Fish/sea/sea18.png") no-repeat 0
      0;
    background-size: 100%;
  }
  36% {
    background: url("../../../../static/images/Fish/sea/sea19.png") no-repeat 0
      0;
    background-size: 100%;
  }
  38% {
    background: url("../../../../static/images/Fish/sea/sea20.png") no-repeat 0
      0;
    background-size: 100%;
  }
  40% {
    background: url("../../../../static/images/Fish/sea/sea21.png") no-repeat 0
      0;
    background-size: 100%;
  }
  42% {
    background: url("../../../../static/images/Fish/sea/sea22.png") no-repeat 0
      0;
    background-size: 100%;
  }
  44% {
    background: url("../../../../static/images/Fish/sea/sea23.png") no-repeat 0
      0;
    background-size: 100%;
  }
  46% {
    background: url("../../../../static/images/Fish/sea/sea24.png") no-repeat 0
      0;
    background-size: 100%;
  }
  48% {
    background: url("../../../../static/images/Fish/sea/sea25.png") no-repeat 0
      0;
    background-size: 100%;
  }
  50% {
    background: url("../../../../static/images/Fish/sea/sea26.png") no-repeat 0
      0;
    background-size: 100%;
  }
  52% {
    background: url("../../../../static/images/Fish/sea/sea27.png") no-repeat 0
      0;
    background-size: 100%;
  }
  54% {
    background: url("../../../../static/images/Fish/sea/sea28.png") no-repeat 0
      0;
    background-size: 100%;
  }
  56% {
    background: url("../../../../static/images/Fish/sea/sea29.png") no-repeat 0
      0;
    background-size: 100%;
  }
  58% {
    background: url("../../../../static/images/Fish/sea/sea30.png") no-repeat 0
      0;
    background-size: 100%;
  }
  60% {
    background: url("../../../../static/images/Fish/sea/sea31.png") no-repeat 0
      0;
    background-size: 100%;
  }
  62% {
    background: url("../../../../static/images/Fish/sea/sea32.png") no-repeat 0
      0;
    background-size: 100%;
  }

  64% {
    background: url("../../../../static/images/Fish/sea/sea33.png") no-repeat 0
      0;
    background-size: 100%;
  }
  66% {
    background: url("../../../../static/images/Fish/sea/sea34.png") no-repeat 0
      0;
    background-size: 100%;
  }
  68% {
    background: url("../../../../static/images/Fish/sea/sea35.png") no-repeat 0
      0;
    background-size: 100%;
  }
  70% {
    background: url("../../../../static/images/Fish/sea/sea36.png") no-repeat 0
      0;
    background-size: 100%;
  }
  72% {
    background: url("../../../../static/images/Fish/sea/sea37.png") no-repeat 0
      0;
    background-size: 100%;
  }
  74% {
    background: url("../../../../static/images/Fish/sea/sea38.png") no-repeat 0
      0;
    background-size: 100%;
  }

  76% {
    background: url("../../../../static/images/Fish/sea/sea39.png") no-repeat 0
      0;
    background-size: 100%;
  }
  78% {
    background: url("../../../../static/images/Fish/sea/sea40.png") no-repeat 0
      0;
    background-size: 100%;
  }
  80% {
    background: url("../../../../static/images/Fish/sea/sea41.png") no-repeat 0
      0;
    background-size: 100%;
  }
  82% {
    background: url("../../../../static/images/Fish/sea/sea42.png") no-repeat 0
      0;
    background-size: 100%;
  }
  84% {
    background: url("../../../../static/images/Fish/sea/sea43.png") no-repeat 0
      0;
    background-size: 100%;
  }
  86% {
    background: url("../../../../static/images/Fish/sea/sea44.png") no-repeat 0
      0;
    background-size: 100%;
  }
  88% {
    background: url("../../../../static/images/Fish/sea/sea45.png") no-repeat 0
      0;
    background-size: 100%;
  }
  90% {
    background: url("../../../../static/images/Fish/sea/sea46.png") no-repeat 0
      0;
    background-size: 100%;
  }

  92% {
    background: url("../../../../static/images/Fish/sea/sea47.png") no-repeat 0
      0;
    background-size: 100%;
  }
  94% {
    background: url("../../../../static/images/Fish/sea/sea48.png") no-repeat 0
      0;
    background-size: 100%;
  }
  96% {
    background: url("../../../../static/images/Fish/sea/sea49.png") no-repeat 0
      0;
    background-size: 100%;
  }
  98% {
    background: url("../../../../static/images/Fish/sea/sea50.png") no-repeat 0
      0;
    background-size: 100%;
  }
  100% {
    background: url("../../../../static/images/Fish/sea/sea51.png") no-repeat 0
      0;
    background-size: 100%;
  }
}
</style>