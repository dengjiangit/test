<template>
  <div class="defaultBlueCat"></div>
</template>

<script>
export default {
  name: "defaultBlueCat"
};
</script>

<style lang="scss" scoped>
.defaultBlueCat {
  width: 375px;
  height: 400px;
  background: url("../../../../static/images/Fish/defaultBlueCat1.png")
    no-repeat 0 0;
  background-size: 100%;
  animation: defaultBlueCatAnimation 2.4s ease-out infinite;
}
@keyframes defaultBlueCatAnimation {
  0% {
    background: url("../../../../static/images/Fish/defaultBlueCat1.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  1.66% {
    background: url("../../../../static/images/Fish/defaultBlueCat2.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  3.32% {
    background: url("../../../../static/images/Fish/defaultBlueCat3.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  5% {
    background: url("../../../../static/images/Fish/defaultBlueCat4.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  6.66% {
    background: url("../../../../static/images/Fish/defaultBlueCat5.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  8.32% {
    background: url("../../../../static/images/Fish/defaultBlueCat6.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  9.98% {
    background: url("../../../../static/images/Fish/defaultBlueCat7.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  11.64% {
    background: url("../../../../static/images/Fish/defaultBlueCat8.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  13.3% {
    background: url("../../../../static/images/Fish/defaultBlueCat9.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  14.96% {
    background: url("../../../../static/images/Fish/defaultBlueCat10.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  16.62% {
    background: url("../../../../static/images/Fish/defaultBlueCat11.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  18.28% {
    background: url("../../../../static/images/Fish/defaultBlueCat12.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  19.94% {
    background: url("../../../../static/images/Fish/defaultBlueCat13.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  21.6% {
    background: url("../../../../static/images/Fish/defaultBlueCat14.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  23.26% {
    background: url("../../../../static/images/Fish/defaultBlueCat15.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  24.92% {
    background: url("../../../../static/images/Fish/defaultBlueCat16.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  26.58% {
    background: url("../../../../static/images/Fish/defaultBlueCat17.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  28.24% {
    background: url("../../../../static/images/Fish/defaultBlueCat18.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  29.9% {
    background: url("../../../../static/images/Fish/defaultBlueCat19.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  31.56% {
    background: url("../../../../static/images/Fish/defaultBlueCat20.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  33.22% {
    background: url("../../../../static/images/Fish/defaultBlueCat21.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  34.88% {
    background: url("../../../../static/images/Fish/defaultBlueCat22.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  36.54% {
    background: url("../../../../static/images/Fish/defaultBlueCat23.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  38.2% {
    background: url("../../../../static/images/Fish/defaultBlueCat24.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  39.86% {
    background: url("../../../../static/images/Fish/defaultBlueCat25.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  41.52% {
    background: url("../../../../static/images/Fish/defaultBlueCat26.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  43.18% {
    background: url("../../../../static/images/Fish/defaultBlueCat27.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  44.84% {
    background: url("../../../../static/images/Fish/defaultBlueCat28.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  46.5% {
    background: url("../../../../static/images/Fish/defaultBlueCat29.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  48.16% {
    background: url("../../../../static/images/Fish/defaultBlueCat30.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  49.82% {
    background: url("../../../../static/images/Fish/defaultBlueCat31.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  51.48% {
    background: url("../../../../static/images/Fish/defaultBlueCat32.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  53.14% {
    background: url("../../../../static/images/Fish/defaultBlueCat33.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  54.8% {
    background: url("../../../../static/images/Fish/defaultBlueCat34.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  46.46% {
    background: url("../../../../static/images/Fish/defaultBlueCat35.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  58.12% {
    background: url("../../../../static/images/Fish/defaultBlueCat36.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  59.78% {
    background: url("../../../../static/images/Fish/defaultBlueCat37.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  61.44% {
    background: url("../../../../static/images/Fish/defaultBlueCat38.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  63.1% {
    background: url("../../../../static/images/Fish/defaultBlueCat39.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  64.76% {
    background: url("../../../../static/images/Fish/defaultBlueCat40.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  66.42% {
    background: url("../../../../static/images/Fish/defaultBlueCat41.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  68.08% {
    background: url("../../../../static/images/Fish/defaultBlueCat42.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  69.74% {
    background: url("../../../../static/images/Fish/defaultBlueCat43.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  71.4% {
    background: url("../../../../static/images/Fish/defaultBlueCat44.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  73.06% {
    background: url("../../../../static/images/Fish/defaultBlueCat45.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  74.72% {
    background: url("../../../../static/images/Fish/defaultBlueCat46.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  76.38% {
    background: url("../../../../static/images/Fish/defaultBlueCat47.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  78.04% {
    background: url("../../../../static/images/Fish/defaultBlueCat48.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  79.7% {
    background: url("../../../../static/images/Fish/defaultBlueCat49.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  81.36% {
    background: url("../../../../static/images/Fish/defaultBlueCat50.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  83.02% {
    background: url("../../../../static/images/Fish/defaultBlueCat51.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  84.68% {
    background: url("../../../../static/images/Fish/defaultBlueCat552.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  86.34% {
    background: url("../../../../static/images/Fish/defaultBlueCat53.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  88% {
    background: url("../../../../static/images/Fish/defaultBlueCat54.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  89.66% {
    background: url("../../../../static/images/Fish/defaultBlueCat55.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  91.32% {
    background: url("../../../../static/images/Fish/defaultBlueCat56.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  92.98% {
    background: url("../../../../static/images/Fish/defaultBlueCat57.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  94.64% {
    background: url("../../../../static/images/Fish/defaultBlueCat58.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  96.3% {
    background: url("../../../../static/images/Fish/defaultBlueCat59.png")
      no-repeat 0 0;
    background-size: 100%;
  }

  97.96% {
    background: url("../../../../static/images/Fish/defaultBlueCat60.png")
      no-repeat 0 0;
    background-size: 100%;
  }
  100% {
    background: url("../../../../static/images/Fish/defaultBlueCat1.png")
      no-repeat 0 0;
    background-size: 100%;
  }
}
</style>