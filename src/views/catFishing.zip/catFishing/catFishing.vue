<template>
  <div class="catFishing">
    <!--天空-->
    <div class="skyBox">
      <header>
        <div class="headerContent">
          <div class="headInfoBox">
            <div
              class="headBox"
              :style="{'background':'url('+headportrait+') center center / cover no-repeat'}"
            ></div>
            <div class="infoBox">
              <p class="userName">{{nickName}}</p>
              <p class="moneyBox">
                <span class="leftBox">
                  <img
                    class="diamondsIcon"
                    src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png"
                    alt
                  />
                  {{balance}}
                </span>
                <img
                  class="rechargeIcon"
                  src="https://coscdn.suresvip.com/app/html/images/Fish/rechargeIcon.png"
                  @click.stop="singleRecharge"
                  alt
                />
              </p>
            </div>
          </div>
          <div class="headBtnBox">
            <button class="recordiconBtn" @click.stop="openRecord"></button>
            <button class="ruleBtn" @click.stop="openRule"></button>
          </div>
        </div>
      </header>
      <div class="trendBox">
        <ul class="trendCatBox">
          <!-- <li></li>
          <li></li>
          <li class="red"></li>
          <li class="flat"></li>
          <li></li>
          <li class="red"></li>
          <li class="flat"></li>
          <li></li>
          <li class="red"></li>
          <li class="flat"></li>
          -->
          <li
            v-for="(item,index) in betResults"
            :class="[item==2?'red':(item==0?'flat':'')]"
            :key="index"
          ></li>
          <li></li>
        </ul>
        <div class="timerBox">
          <div class="leftFishBox">
            <div class="timerInfo" v-show="step==0">未开始</div>
            <div class="timerInfo" v-show="step==1">投注环节</div>
            <!-- <div class="timerInfo" v-if="step==1">投注结果</div> -->
            <ul class="timerInfoContent" v-show="step==2">
              <li v-for="(item,index) in 5" :class="[currentblueNum>index?'active':'']"></li>
              <!-- <li></li>
              <li></li>
              <li></li>
              <li></li>-->
            </ul>
          </div>
          <p class="timerBox">{{stepRemain}}</p>

          <div class="rightFishBox">
            <div class="timerInfo" v-show="step==0">未开始</div>
            <div class="timerInfo" v-show="step==1">投注环节</div>
            <ul class="timerInfoContent" v-show="step==2">
              <li v-for="(item,index) in 5" :class="[currentredNum>index?'active':'']"></li>
            </ul>
          </div>
        </div>
      </div>
      <!-- {{timerAll}} -->
      <!-- <div class="leftShip"></div> -->
      <div class="blueCat" ref="blueCat">
        <canvas id="blueCat" ref="canvas1"></canvas>
      </div>
      <!-- <div class="rightShip"></div> -->
      <div class="redCat" ref="redCat">
        <canvas id="redCat" ref="canvas2"></canvas>
      </div>
    </div>
    <!--海面-->
    <div class="seaBox">
      <div class="seaComp" ref="seaComp">
        <canvas id="sea" ref="sea"></canvas>
        <!-- <sea /> -->
      </div>
      <!--投注详情-->
      <div class="bettingDetails" v-show="bettingState">
        <div
          class="blueBettingBox betting"
          :class="[index==0?'flatBettingBox':(index==2?'redBettingBox':'')]"
          v-for="(item,index) in userBase"
          :key="index"
        >
          <div class="betting_top">
            <p class="userCat" v-if="index==1">支持黑猫</p>
            <p class="userCat" v-if="index==0">平局</p>
            <p class="userCat" v-if="index==2">支持红猫</p>
            <p class="userNumber">{{item.sum}}</p>
          </div>
          <ul class="betting_content">
            <li v-for="(item2,index) in item">
              <div class="headBox" v-bg-img="item2.userHead"></div>
              <span>{{item2.betTotal}}</span>
            </li>
          </ul>
        </div>
        <!-- <div class="flatBettingBox betting">
           <div class="betting_top">
            <p class="userCat">平局</p>
            <p class="userNumber">123123123</p>
          </div>
          <ul class="betting_content">
            <li>
              <div class="headBox"></div>
              <span>524580</span>
            </li>
            <li>
              <div class="headBox"></div>
              <span>524580</span>
            </li>
            <li></li>
            <li></li>
            <li></li>
          </ul>
        </div>
        <div class="redBettingBox betting">
          <div class="betting_top">
            <p class="userCat">支持红猫</p>
            <p class="userNumber">123123123</p>
          </div>
          <ul class="betting_content">
            <li>
              <div class="headBox"></div>
              <span>524580</span>
            </li>
            <li>
              <div class="headBox"></div>
              <span>524580</span>
            </li>
            <li></li>
            <li></li>
            <li></li>
          </ul>
        </div>-->
      </div>
      <!--提示信息-->
      <div class="seaInfo" v-show="step==1">
        <!-- <br>对决还有{{stepRemain}}s开始</br>  -->
        快来猜猜黑猫还是红猫赢哦~
      </div>
    </div>
    <!--底部-->
    <div class="footerBox" :class="[stakeStatus?'stakeOpen':'stakeclose']">
      <button
        class="stakeBtn"
        @click.stop="openStake"
        :class="[stakeStatus?'stakeopen':'stakeclose']"
      ></button>
      <ul class="RecodeBox" v-if="RecodeState&&MyBetData.length">
        <li v-for="(item,index) in MyBetData" :key="index" v-if="item.total">
          <img
            src="https://coscdn.suresvip.com/app/html/images/Fish/flatCatHead.png"
            alt
            v-if="index==0"
          />
          <img
            src="https://coscdn.suresvip.com/app/html/images/Fish/blueCatHead.png"
            alt
            v-if="index==1"
          />
          <img
            src="https://coscdn.suresvip.com/app/html/images/Fish/redCatHead.png"
            alt
            v-if="index==2"
          />
          <span>{{item.total}}</span>
        </li>
      </ul>
      <div class="stakeBox" v-if="stakeStatus">
        <ul>
          <li @click.stop="clickBets(item)" v-for="(item,index) in dateBlueDate" :key="index">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
            <span>{{item.grade}}</span>
            <span class="Multiple" v-show="item.double>=1">x{{item.double}}</span>
          </li>
        </ul>
        <ul>
          <li @click.stop="clickBets(item)" v-for="(item,index) in dateflagDate" :key="index">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
            <span>{{item.grade}}</span>
            <span class="Multiple" v-show="item.double>=1">x{{item.double}}</span>
          </li>
        </ul>
        <ul>
          <li @click.stop="clickBets(item)" v-for="(item,index) in dateredDate" :key="index">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
            <span>{{item.grade}}</span>
            <span class="Multiple" v-show="item.double>=1">x{{item.double}}</span>
          </li>
        </ul>
        <!-- <li @click.stop="clickBets(item)" v-for="(item,index) in GradeArr">
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>{{item.grade}}</span>
          <span class="Multiple" v-show="item.double>=1">x{{item.double}}</span>
        </li>-->
        <!-- <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>1000</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>1000</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>100</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>100</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>100</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>10</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>10</span>
        </li>
        <li>
          <img src="https://coscdn.suresvip.com/app/html/images/Fish/diamondsIcon.png" alt />
          <span>10</span>
        </li>-->
      </div>
      <ul class="footerContent" @click="openbetsDetali">
        <li class="info blue">
          <div class="infoContent">
            <div class="info_Content">
              <p class="catName">黑猫赢</p>
              <p class="catNumber">{{blueCatNum}}</p>
            </div>
          </div>
        </li>
        <li class="info info2">
          <div class="infoContent">
            <p class="pingdraw">平</p>
            <p class="pingNumber">{{flagCatNum}}</p>
          </div>
        </li>
        <li class="info red">
          <div class="infoContent">
            <div class="info_Content">
              <p class="catName">红猫赢</p>
              <p class="catNumber">{{redCatNum}}</p>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="fixedBox" v-if="startModule">
      <div class="logoDiv"></div>
      <div class="loadPressBox">
        <div class="loadPressDiv" :style="{'width':loadingNumber+'%'}">
          <p>{{loadingNumber |parse}}%</p>
        </div>
      </div>

      <div class="loadAnimate">
        <span>loading</span>
        <div class="loadspotBox">
          <span class="loadspot"></span>
          <span class="loadspot"></span>
          <span class="loadspot"></span>
        </div>
      </div>
    </div>
    <!--结果弹窗-->
    <div class="resultModule" v-if="resultState">
      <div class="logoDiv"></div>
      <div class="buleResultBox">
        <span class="fishNumber">{{blueNum}}</span>
        <div :class="[blueNum<redNum?'catnowin':'catwin']"></div>
        <span class="Result" :class="[blueNum<redNum?'fu':(blueNum>redNum?'win':'ping')]"></span>
      </div>
      <div class="redResultBox">
        <span class="fishNumber">{{redNum}}</span>
        <div :class="[blueNum>redNum?'catnowin':'catwin']"></div>
        <span class="Result" :class="[blueNum>redNum?'fu':(blueNum<redNum?'win':'ping')]"></span>
      </div>
    </div>
    <div class="noVulgars" v-if="Vulgar">
      <div class="logoDiv"></div>
      <p class="info">土豪值过低不能一起玩耍哦</p>
    </div>
    <!--游戏规则和游戏记录规则-->
    <div class="ruleRecordModule" v-if="ruleRecordState" @click.stop="closeRuleRecord($event)">
      <!--游戏规则-->
      <div class="ruleBox" v-if="ruleStatus" ref="ruleBox">
        <h3>游戏规则</h3>
        <p>
          1.钓鱼准备市场为a秒，准备过程中对小猫钓鱼比赛的结果进行
          竞猜。钓鱼市场b秒。钓鱼中不能竞猜。
        </p>
        <p>
          2.黑猫钓鱼数量更多则为黑猫赢，红猫钓鱼数量更多则为红猫赢
          两猫钓鱼数量相同则为平局。
        </p>
        <p>
          3.猜中结果的用户获得与投注钻石数等同的钻石作为奖励，对战
          结果展示完毕后自动到账。
        </p>
        <p>
          4.邀请用户参与游戏，能够获得用户投注数的1%作为邀请奖励，
          被邀请的用户需在红包邀请页面中填写邀请人的邀请码（即用户
          id）
        </p>
        <div class="Commission">
          <span class="info">当前佣金:</span>
          <input type="text" v-model="Diamonds" readonly="readOnly" />
          <button @click.stop="ReceiveBtn"></button>
        </div>
        <p class="yaoqinginfo">马上邀请</p>
        <!-- <ul class="Invitation">
          <li @click="shareh5Url(0)">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/wechatIcon.png" alt />
            <p>微信好友</p>
          </li>
          <li @click="shareh5Url(1)">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/friendsIcon.png" alt />
            <p>朋友圈</p>
          </li>
          <li @click="shareh5Url(2)">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/qqIcon.png" alt />
            <p>QQ好友</p>
          </li>
          <li @click="shareh5Url(3)">
            <img src="https://coscdn.suresvip.com/app/html/images/Fish/qqSpaceIcon.png" alt />
            <p>QQ空间</p>
          </li>
        </ul> -->
      </div>
      <!--游戏记录-->
      <div class="RecordBox" v-if="recordStatus" ref="RecordBox">
        <h3>游戏记录</h3>
        <ul class="RecordContent">
          <li v-for="(item,index) in logsDetail" :key="index">
            <div class="leftInfo">
              <span class="winName" v-if="item.result==1">黑猫胜出</span>
              <span class="winName" v-if="item.result==2">红猫胜出</span>
              <span class="winName" v-if="item.result==0">平局胜出</span>
              <p>
                <span class="touru" v-if="item.betIndex==0">
                  <img src="https://coscdn.suresvip.com/app/html/images/Fish/flatCatIcon.png" alt /> 下注平局
                </span>
                <span class="touru" v-if="item.betIndex==1">
                  <img src="https://coscdn.suresvip.com/app/html/images/Fish/blueCatIcon.png" alt /> 下注黑猫
                </span>
                <span class="touru" v-if="item.betIndex==2">
                  <img src="https://coscdn.suresvip.com/app/html/images/Fish/redCatIcon.png" alt /> 下注红猫
                </span>
              </p>
            </div>
            <div class="rightInfo">
              <span class="winNumber" v-if="item.betIndex==item.result">+{{item.betTotal}}钻石</span>
              <span class="winNumber" v-if="item.betIndex!=item.result">-{{item.betTotal}}钻石</span>
              <span class="timer">{{item.logTime |turnDate}}</span>
            </div>
          </li>
          <!-- <li>
            <div class="leftInfo">
              <span class="winName">黑猫胜出</span>
              <p>
                <span class="touru">
                  <img src="https://coscdn.suresvip.com/app/html/images/Fish/redCatIcon.png" alt /> 下注红猫赢
                </span>
              </p>
            </div>
            <div class="rightInfo">
              <span class="winNumber">+500钻石</span>
              <span class="timer">2019/04/31 00:34</span>
            </div>
          </li>-->
          <!-- <li>
            <div class="leftInfo">
              <span class="winName">黑猫胜出</span>
              <p>
                <span class="touru">
                  <img src="https://coscdn.suresvip.com/app/html/images/Fish/blueCatIcon.png" alt /> 下注黑猫赢
                </span>
              </p>
            </div>
            <div class="rightInfo">
              <span class="winNumber">+500钻石</span>
              <span class="timer">2019/04/31 00:34</span>
            </div>
          </li>-->
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import MD5 from "js-md5";
import axios from "axios";
import {
  getQueryString,
  singleRecharge,
  shareh5Url
} from "@/utils/appMethods.js";
import $root from "@/proto/proto.js";
let protobuf = require("protobufjs/minimal");
const $Reader = protobuf.Reader;
import sea from "./components/sea.vue";
export default {
  name: "catFishing",
  data() {
    return {
      stepTime: 0, //当前阶段总时间
      currentblueNum: 0, //当前黑的数量
      currentredNum: 0, //当前红的数量
      fishStatus: 1, //1.等待，2，上钩3，没上钩灰猫
      fishStatus2: 1, //等待蓝猫
      Vulgar: false, //土豪值
      bluebarsNumber: [],
      redbarsNumber: [],
      Activetimer: null,
      throttleArr: [],
      throttlenowTime: null,
      throttleLastTime: null, //节流上一次点击事件
      throttleTimer: null, //节流定时器
      throttleDelay: 2000, //节流时间
      MyBetData: "", //我的投注
      heartTimer: 30 * 1000, //心跳倒计时
      heartTimeout: null,
      wsNum: 4, //失败后重连4次
      timeoutnum: null, //重连倒计时
      Diamonds: 0, //钻石
      logsDetail: [], //
      imgBase: "https://coscdn.suresvip.com/app/html/smashEgg/",
      userImgBaseUrl: "https://cosimg.suresvip.com/app/logo/user/", //头像base
      userImgBaseUrl2: "https://cosimg.suresvip.com/app/logo/randomlogo/", //随机头像base
      timerAll: 60,
      userBase: [],
      blueCatNum: 0,
      flagCatNum: 0,
      redCatNum: 0,
      timer: null,
      timer2: null,
      timer3: null,
      getAllArr: [5, 10, 12],
      headportrait: "",
      nickName: "",
      loadingNumber: 0, //加载进度
      startModule: true, //开始load
      stakeStatus: false, //投注面板
      RecodeState: false, //投注记录
      infoState: false, //投注提示信息
      bettingState: false, //投注详情
      ruleRecordState: false, //游戏规则记录规则状态
      resultState: false, //结果弹窗
      ruleStatus: false, //游戏规则
      recordStatus: false, //游戏记录
      step: "", //当前阶段当前阶段:0,未开始,1下注,2钓鱼,3结算中
      stepRemain: "", //当前阶段剩余时间当前阶段:当前阶段下剩余时间ms
      balance: "", //余额
      betResults: 0, //历史结果:0平局,1蓝猫赢,2红猫赢
      allBetData: 0, //总投注+我的投注明细
      roundData: 0, //钓鱼结果数据step=2+3
      dateBlueDate: [
        { grade: 10, double: 0, betIndex: 1, click: 1, type: 1 },
        { grade: 100, double: 0, betIndex: 1, click: 1, type: 2 },
        { grade: 1000, double: 0, betIndex: 1, click: 1, type: 3 }
      ],
      dateflagDate: [
        { grade: 10, double: 0, betIndex: 0, click: 1, type: 4 },
        { grade: 100, double: 0, betIndex: 0, click: 1, type: 5 },
        { grade: 1000, double: 0, betIndex: 0, click: 1, type: 6 }
      ],
      dateredDate: [
        { grade: 10, double: 0, betIndex: 2, click: 1, type: 7 },
        { grade: 100, double: 0, betIndex: 2, click: 1, type: 8 },
        { grade: 1000, double: 0, betIndex: 2, click: 1, type: 9 }
      ],
      userId: "",
      imgblueAll: [
        //加载所有动画图片
        "defaultBlueCat1",
        "defaultBlueCat2",
        "defaultBlueCat3",
        "defaultBlueCat4",
        "defaultBlueCat5",
        "defaultBlueCat6",
        "defaultBlueCat7",
        "defaultBlueCat8",
        "defaultBlueCat9",
        "defaultBlueCat10",
        "defaultBlueCat11",
        "defaultBlueCat12",
        "defaultBlueCat13",
        "defaultBlueCat14",
        "defaultBlueCat15",
        "defaultBlueCat16",
        "defaultBlueCat17",
        "defaultBlueCat18",
        "defaultBlueCat19",
        "defaultBlueCat20",
        "defaultBlueCat21",
        "defaultBlueCat22",
        "defaultBlueCat23",
        "defaultBlueCat24",
        "defaultBlueCat25",
        "defaultBlueCat26",
        "defaultBlueCat27",
        "defaultBlueCat28",
        "defaultBlueCat29",
        "defaultBlueCat30",
        "defaultBlueCat31",
        "defaultBlueCat32",
        "defaultBlueCat33",
        "defaultBlueCat34",
        "defaultBlueCat35",
        "defaultBlueCat36",
        "defaultBlueCat37",
        "defaultBlueCat38",
        "defaultBlueCat39",
        "defaultBlueCat40",
        "swingblue1",
        "swingblue2",
        "swingblue3",
        "swingblue4",
        "swingblue5",
        "swingblue6",
        "swingblue7",
        "swingblue8",
        "swingblue9",
        "swingblue10",
        "swingblue11",
        "swingblue12",
        "swingblue13",
        "swingblue14",
        "swingblue15",
        "swingblue16",
        "swingblue17",
        "swingblue18",
        "swingblue19",
        "swingblue20",
        "swingblue21",
        "swingblue22",
        "swingblue23",
        "swingblue24",
        "swingblue25",
        "swingblue26",
        "swingblue27",
        "swingblue28",
        "swingblue29",
        "swingblue30",
        "swingblue31",
        "swingblue32",
        "swingblue33",
        "swingblue34",
        "swingblue35",
        "swingblue36",
        "swingblue37",
        "swingblue38",
        "swingblue39",
        "swingblue40",
        "swingblue41",
        "waitblueCat1",
        "waitblueCat2",
        "waitblueCat3",
        "waitblueCat4",
        "waitblueCat5",
        "waitblueCat6",
        "waitblueCat7",
        "waitblueCat8",
        "waitblueCat9",
        "waitblueCat10",
        "waitblueCat11",
        "waitblueCat12",
        "waitblueCat13",
        "waitblueCat14",
        "waitblueCat15",
        "waitblueCat16",
        "waitblueCat17",
        "waitblueCat18",
        "waitblueCat19",
        "waitblueCat20",
        "waitblueCat21",
        "waitblueCat22",
        "waitblueCat23",
        "waitblueCat24",
        "waitblueCat25",
        "waitblueCat26",
        "waitblueCat27",
        "waitblueCat28",
        "waitblueCat29",
        "waitblueCat30",
        "waitblueCat31",
        "waitblueCat32",
        "waitblueCat33",
        "waitblueCat34",
        "waitblueCat35",
        "waitblueCat36",
        "waitblueCat37",
        "waitblueCat38",
        "waitblueCat39",
        "waitblueCat40",
        "hookedupblue1",
        "hookedupblue2",
        "hookedupblue3",
        "hookedupblue4",
        "hookedupblue5",
        "hookedupblue6",
        "hookedupblue7",
        "hookedupblue8",
        "hookedupblue9",
        "hookedupblue10",
        "hookedupblue11",
        "hookedupblue12",
        "hookedupblue13",
        "hookedupblue14",
        "hookedupblue15",
        "hookedupblue16",
        "hookedupblue17",
        "hookedupblue18",
        "hookedupblue19",
        "hookedupblue20",
        "hookedupblue21",
        "hookedupblue22",
        "hookedupblue23",
        "hookedupblue24",
        "hookedupblue25",
        "hookedupblue26",
        "hookedupblue27",
        "hookedupblue28",
        "hookedupblue29",
        "hookedupblue30",
        "hookedupblue31",
        "hookedupblue32",
        "hookedupblue33",
        "hookedupblue34",
        "hookedupblue35",
        "hookedupblue36",
        "hookedupblue37",
        "hookedupblue38",
        "hookedupblue39",
        "hookedupblue40",
        "nohookedupblue1",
        "nohookedupblue2",
        "nohookedupblue3",
        "nohookedupblue4",
        "nohookedupblue5",
        "nohookedupblue6",
        "nohookedupblue7",
        "nohookedupblue8",
        "nohookedupblue9",
        "nohookedupblue10",
        "nohookedupblue11",
        "nohookedupblue12",
        "nohookedupblue13",
        "nohookedupblue14",
        "nohookedupblue15",
        "nohookedupblue16",
        "nohookedupblue17",
        "nohookedupblue18",
        "nohookedupblue19",
        "nohookedupblue20",
        "nohookedupblue21",
        "nohookedupblue22",
        "nohookedupblue23",
        "nohookedupblue24",
        "nohookedupblue25",
        "nohookedupblue26",
        "nohookedupblue27",
        "nohookedupblue28",
        "nohookedupblue29",
        "nohookedupblue30",
        "nohookedupblue31",
        "nohookedupblue32",
        "nohookedupblue33",
        "nohookedupblue34",
        "nohookedupblue35",
        "nohookedupblue36",
        "nohookedupblue37",
        "nohookedupblue38",
        "nohookedupblue39",
        "nohookedupblue40"
      ],
      imgredAll: [
        "defaultRedcat1",
        "defaultRedcat2",
        "defaultRedcat3",
        "defaultRedcat4",
        "defaultRedcat5",
        "defaultRedcat6",
        "defaultRedcat7",
        "defaultRedcat8",
        "defaultRedcat9",
        "defaultRedcat10",
        "defaultRedcat11",
        "defaultRedcat12",
        "defaultRedcat13",
        "defaultRedcat14",
        "defaultRedcat15",
        "defaultRedcat16",
        "defaultRedcat17",
        "defaultRedcat18",
        "defaultRedcat19",
        "defaultRedcat20",
        "defaultRedcat21",
        "defaultRedcat22",
        "defaultRedcat23",
        "defaultRedcat24",
        "defaultRedcat25",
        "defaultRedcat26",
        "defaultRedcat27",
        "defaultRedcat28",
        "defaultRedcat29",
        "defaultRedcat30",
        "defaultRedcat31",
        "defaultRedcat32",
        "defaultRedcat33",
        "defaultRedcat34",
        "defaultRedcat35",
        "defaultRedcat36",
        "defaultRedcat37",
        "defaultRedcat38",
        "defaultRedcat39",
        "defaultRedcat40",
        "swingred1",
        "swingred2",
        "swingred3",
        "swingred4",
        "swingred5",
        "swingred6",
        "swingred7",
        "swingred8",
        "swingred9",
        "swingred10",
        "swingred11",
        "swingred12",
        "swingred13",
        "swingred14",
        "swingred15",
        "swingred16",
        "swingred17",
        "swingred18",
        "swingred19",
        "swingred20",
        "swingred21",
        "swingred22",
        "swingred23",
        "swingred24",
        "swingred25",
        "swingred26",
        "swingred27",
        "swingred28",
        "swingred29",
        "swingred30",
        "swingred31",
        "swingred32",
        "swingred33",
        "swingred34",
        "swingred35",
        "swingred36",
        "swingred37",
        "swingred38",
        "swingred39",
        "swingred40",
        "swingred41",
        "waitredCat1",
        "waitredCat2",
        "waitredCat3",
        "waitredCat4",
        "waitredCat5",
        "waitredCat6",
        "waitredCat7",
        "waitredCat8",
        "waitredCat9",
        "waitredCat10",
        "waitredCat11",
        "waitredCat12",
        "waitredCat13",
        "waitredCat14",
        "waitredCat15",
        "waitredCat16",
        "waitredCat17",
        "waitredCat18",
        "waitredCat19",
        "waitredCat20",
        "waitredCat21",
        "waitredCat22",
        "waitredCat23",
        "waitredCat24",
        "waitredCat25",
        "waitredCat26",
        "waitredCat27",
        "waitredCat28",
        "waitredCat29",
        "waitredCat30",
        "waitredCat31",
        "waitredCat32",
        "waitredCat33",
        "waitredCat34",
        "waitredCat35",
        "waitredCat36",
        "waitredCat37",
        "waitredCat38",
        "waitredCat39",
        "waitredCat40",

        "hookedupred1",
        "hookedupred2",
        "hookedupred3",
        "hookedupred4",
        "hookedupred5",
        "hookedupred6",
        "hookedupred7",
        "hookedupred8",
        "hookedupred9",
        "hookedupred10",
        "hookedupred11",
        "hookedupred12",
        "hookedupred13",
        "hookedupred14",
        "hookedupred15",
        "hookedupred16",
        "hookedupred17",
        "hookedupred18",
        "hookedupred19",
        "hookedupred20",
        "hookedupred21",
        "hookedupred22",
        "hookedupred23",
        "hookedupred24",
        "hookedupred25",
        "hookedupred26",
        "hookedupred27",
        "hookedupred28",
        "hookedupred29",
        "hookedupred30",
        "hookedupred31",
        "hookedupred32",
        "hookedupred33",
        "hookedupred34",
        "hookedupred35",
        "hookedupred36",
        "hookedupred37",
        "hookedupred38",
        "hookedupred39",
        "hookedupred40",
        "nohookedupred1",
        "nohookedupred2",
        "nohookedupred3",
        "nohookedupred4",
        "nohookedupred5",
        "nohookedupred6",
        "nohookedupred7",
        "nohookedupred8",
        "nohookedupred9",
        "nohookedupred10",
        "nohookedupred11",
        "nohookedupred12",
        "nohookedupred13",
        "nohookedupred14",
        "nohookedupred15",
        "nohookedupred16",
        "nohookedupred17",
        "nohookedupred18",
        "nohookedupred19",
        "nohookedupred20",
        "nohookedupred21",
        "nohookedupred22",
        "nohookedupred23",
        "nohookedupred24",
        "nohookedupred25",
        "nohookedupred26",
        "nohookedupred27",
        "nohookedupred28",
        "nohookedupred29",
        "nohookedupred30",
        "nohookedupred31",
        "nohookedupred32",
        "nohookedupred33",
        "nohookedupred34",
        "nohookedupred35",
        "nohookedupred36",
        "nohookedupred37",
        "nohookedupred38",
        "nohookedupred39",
        "nohookedupred40"
      ],
      seaImg:[
        'sea1',
        'sea2',
        'sea3',
        'sea4',
        'sea5',
        'sea6',
        'sea7',
        'sea8',
        'sea9',
        'sea10',
        'sea11',
        'sea12',
        'sea13',
        'sea14',
        'sea15',
        'sea16',
        'sea17',
        'sea18',
        'sea19',
        'sea20',
        'sea21',
        'sea22',
        'sea23',
        'sea24',
        'sea25',
        'sea26',
        'sea27',
        'sea28',
        'sea29',
        'sea30',
        'sea31',
        'sea32',
        'sea33',
        'sea34',
        'sea35',
        'sea36',
        'sea37',
        'sea38',
        'sea39',
        'sea40',
        'sea41',
        'sea42',
        'sea43',
        'sea44',
        'sea45',
        'sea46',
        'sea47',
        'sea48',
        'sea49',
        'sea50',
        'sea51',
      ],
      seaImgArr:[],
      GradeArr: [
        { grade: 1000, double: 0 },
        { grade: 1000, double: 0 },
        { grade: 1000, double: 0 },
        { grade: 100, double: 0 },
        { grade: 100, double: 0 },
        { grade: 100, double: 0 },
        { grade: 10, double: 0 },
        { grade: 10, double: 0 },
        { grade: 10, double: 0 }
      ],
      defaultBlueAll: [],
      blueNum: 0,
      redNum: 0,
      defaultRedAll: [],
      defaultblueIndex5: 0, //无上钩索引
      defaultblueIndex4: 0, //上钩索引
      defaultblueIndex3: 0, //等待索引
      defaultblueIndex2: 0, //甩杆索引
      defaultblueIndex: 0,
      defaultredIndex5: 0,
      defaultredIndex4: 0,
      defaultredIndex3: 0,
      defaultredIndex2: 0, //甩杆索引
      defaultredIndex: 0, //
      defaultActive: 0, //默认动画
      defaultActive2: 0, //默认动画
      isBets: true, //是否可以下注
      Interfacenumber: 0, //接口递增
      swingblueImg: [], //甩杠动画
      swingredImg: [], //甩杠动画
      waitblueImg: [], //
      waitredImg: [], //等待图片
      hookedupblueImg: [], //钓到鱼
      hookedupredImg: [],
      nohookedupblueImg: [], //未上钩
      nohookedupredImg: [],
      version: "",
      channels: "",
      versionArr: [],
      chanelsArr: [],
      open: true //否是活动进制
    };
  },
  created() {
    this.userId = getQueryString("userId");
    this.version = getQueryString("version");
    this.channels = getQueryString("channels");
     this.preloadimages3(this.seaImg);
    this.websocketstart();
    if (!this.Vulgar) {
      this.preloadimages(this.imgblueAll);
      this.preloadimages2(this.imgredAll);
    }
    // this.enter();

    // this.readExcel();
  },

  beforeDestroy() {
    clearInterval(this.timer);
    clearInterval(this.heartTimeout);
    this.timer = null;
    this.leave();
  },
  watch: {
    loadingNumber(num) {
      if (num >= 100) {
        this.startModule = false;
        this.infoState = true;
        this.defaultAnimation();
        this.defaultAnimation2();
        // this.timerAllDowm();
      }
    },
    step(num) {
      if (num == 1) {
        (this.currentblueNum = 0), //当前黑的数量
          (this.currentredNum = 0), //当前红的数量
          (this.fishStatus = 1), //1.等待，2，上钩3，没上钩灰猫
          (this.fishStatus2 = 1), //等待蓝猫
          (this.resultState = false);
        // this.bettingState = false;
        this.defaultActive = 0;
        this.defaultActive2 = 0;
        
      } else if (num == 2) {
        this.getUserBetDetail();
        // this.bettingState = true;
        this.RecodeState = false;
        this.defaultblueIndex2 = 0;
        this.defaultredIndex2 = 0;
        this.defaultActive2 = 1;
        this.defaultActive = 1;
      }
      // else if (num == 2) {
      //   this.websocket.send(this.enterData());
      //   this.defaultActive2 = 2;
      //   this.defaultActive = 2;
      // } else if (num == 3) {
      //   this.defaultActive = 0;
      //   this.defaultActive2 = 0;
      //   this.resultState = true;
      // }
    }
  },
  components: {
    sea
  },
  filters: {
    parse(val) {
      return parseInt(val);
    },
    turnDate(val) {
      var d = new Date(val); //根据时间戳生成的时间对象
      let date =
        d.getFullYear() +
        "/" +
        (d.getMonth() + 1) +
        "/" +
        d.getDate() +
        " " +
        d.getHours() +
        ":" +
        d.getMinutes();
      return date;
    }
  },
  beforeDestroy() {},
  methods: {
    openbetsDetali(){
      this.bettingState=!this.bettingState;
      if( this.bettingState){
        this.getUserBetDetail();
      }
     
    },
    shareh5Url(val) {
      shareh5Url(val, "http://192.168.101.6:8090/catFishShareing");
    },
    //充值
    singleRecharge() {
      singleRecharge(100);
    },
    //递归
    goFishNext1(index) {
      if (index >= this.bluebarsNumber.length) {
        this.fishStatus = 1;
        return;
      }
      let current = this.bluebarsNumber[index];

      if (current > 0) {
        // console.log("current1", current);
        setTimeout(() => {
          if (this.defaultActive == 0) {
            this.defaultActive = 1;
          }

          this.fishStatus = 2;
          this.goFishNext1(++index);
        }, (current - 2) * 1000);
      } else {
        // console.log("current2", current);
        setTimeout(() => {
          if (this.defaultActive == 0) {
            this.defaultActive = 1;
          }
          this.fishStatus = 3;
          this.goFishNext1(++index);
        }, (Math.abs(current) - 2) * 1000);
      }
    },
    goFishNext2(index) {
      if (index >= this.redbarsNumber.length) {
        // this.defaultredIndex5 = 0;
        this.fishStatus2 = 1;
        // console.log()
        return;
      }
      let current = this.redbarsNumber[index];
      if (current > 0) {
        console.log("current3", current, this.redbarsNumber);
        setTimeout(() => {
          if (this.defaultActive2 == 0) {
            this.defaultActive2 = 1;
          }
          this.fishStatus2 = 2;
          this.goFishNext2(++index);
        }, (current - 1) * 1000);
      } else {
        console.log("current4", index, current, this.redbarsNumber);
        setTimeout(() => {
          if (this.defaultActive2 == 0) {
            this.defaultActive2 = 1;
          }
          this.defaultredIndex5 = 0;
          this.fishStatus2 = 3;
          this.goFishNext2(++index);
        }, (Math.abs(current) - 1) * 1000);
      }
    },
    // //钓鱼
    // goFish(arr) {
    //   let fishTime1 = null,
    //     fishTime2 = null;
    //   if (!arr) {
    //     this.fishStatus = 1;
    //     this.defaultActive = 2;
    //     return;
    //   }
    //   for (var i = 0; i < 8; i++) {
    //     if (arr[i]) {
    //       console.log("blueFish", arr[i]);
    //       if (arr[i] >= 0) {
    //         // clearTimeout(fishTime1);
    //         // clearTimeout(fishTime2);
    //         fishTime1 = setTimeout(() => {
    //           if (this.defaultActive == 0) {
    //             this.defaultActive = 1;
    //           }
    //           this.fishStatus = 2;
    //         }, (arr[i] - 2) * 1000);
    //       } else {
    //         // clearTimeout(fishTime1);
    //         // clearTimeout(fishTime2);
    //         fishTime2 = setTimeout(() => {
    //           if (this.defaultActive == 0) {
    //             this.defaultActive = 1;
    //           }
    //           this.fishStatus = 3;
    //         }, (Math.abs(arr[i]) - 2) * 1000);
    //       }
    //     } else {
    //       clearTimeout(fishTime1);
    //       clearTimeout(fishTime2);
    //       this.fishStatus = 1;
    //       this.defaultActive = 2;
    //     }
    //   }
    //   // arr.forEach((item, index) => {
    //   //   if (item > 0) {
    //   //     console.log(item);
    //   //     clearTimeout(fishTime1);
    //   //     fishTime1 = setTimeout(() => {
    //   //       if (this.defaultActive == 0) {
    //   //         this.defaultActive = 1;
    //   //       }
    //   //       this.fishStatus = 2;
    //   //       // this.defaultActive = 3;
    //   //     }, arr[index] * 1000);
    //   //   } else {
    //   //     clearTimeout(fishTime2);
    //   //     fishTime2 = setTimeout(() => {
    //   //       if (this.defaultActive == 0) {
    //   //         this.defaultActive = 1;
    //   //       }
    //   //       this.fishStatus = 3;
    //   //     }, Math.abs(arr[index]) * 1000);
    //   //   }
    //   // });
    // },
    // goFish2(arr) {
    //   let fishTime1 = null,
    //     fishTime2 = null;
    //   // arr.forEach((item, index) => {
    //   //   if (item > 0) {
    //   //     console.log(item);
    //   //     clearTimeout(fishTime1);
    //   //     fishTime1 = setTimeout(() => {
    //   //       if (this.defaultActive2 == 0) {
    //   //         this.defaultActive2 = 1;
    //   //       }
    //   //       this.fishStatus2 = 2;
    //   //       // this.defaultActive = 3;
    //   //     }, arr[index] * 1000);
    //   //   } else {
    //   //     clearTimeout(fishTime2);
    //   //     fishTime2 = setTimeout(() => {
    //   //       if (this.defaultActive2 == 0) {
    //   //         this.defaultActive2 = 1;
    //   //       }
    //   //       this.fishStatus2 = 3;
    //   //     }, Math.abs(arr[index]) * 1000);
    //   //   }
    //   // });
    //   if (!arr) {
    //     this.fishStatus2 = 1;
    //     this.defaultActive2 = 2;
    //     return;
    //   }
    //   for (var i = 0; i < 8; i++) {
    //     if (arr[i]) {
    //       if (arr[i] >= 0) {
    //         clearTimeout(fishTime1);
    //         fishTime1 = setTimeout(() => {
    //           if (this.defaultActive2 == 0) {
    //             this.defaultActive2 = 1;
    //           }
    //           this.fishStatus2 = 2;
    //         }, (arr[i] - 2) * 1000);
    //       } else {
    //         clearTimeout(fishTime2);
    //         fishTime2 = setTimeout(() => {
    //           if (this.defaultActive2 == 0) {
    //             this.defaultActive2 = 1;
    //           }
    //           this.fishStatus2 = 3;
    //         }, (Math.abs(arr[i]) - 2) * 1000);
    //       }
    //     } else {
    //       clearTimeout(fishTime1);
    //       clearTimeout(fishTime2);
    //       this.fishStatus2 = 1;
    //       this.defaultActive2 = 2;
    //     }
    //   }
    // },
    //查看所有玩家的投注明细
    getUserBetDetail() {
      let data = this.getbodyBytes($root.FishCmd.getUserBetDetail, {
        userId: this.userId
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1295, data);
      this.websocket.send(result);
    },
    //领取佣金
    ReceiveBtn() {
      let data = this.getbodyBytes($root.FishCmd.drawCommission, {
        userId: this.userId
      });
      console.log({
        userId: this.userId
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1293, data);
      this.websocket.send(result);
    },
    //获取我的佣金
    getmyCommission() {
      let data = this.getbodyBytes($root.FishCmd.getCommission, {
        userId: this.userId
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1292, data);
      this.websocket.send(result);
    },
    //获取我的投注记录
    getRecoreDate() {
      let data = this.getbodyBytes($root.FishCmd.getBetLog, {
        userId: this.userId,
        start: 1,
        end: 100
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1296, data);
      this.websocket.send(result);
    },
    //我的投注明细
    getMyBeteDetail() {
      let data = this.getbodyBytes($root.FishCmd.getMyBets, {
        userId: this.userId
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1294, data);
      this.websocket.send(result);
    },
    getSendUint8Array(seq, cmdId, bodyBytes) {
      seq++;
      this.Interfacenumber = seq;
      const bodyLen = bodyBytes ? bodyBytes.length : 0;
      const bytes = new Uint8Array(4 + 4 + 4 + 4 + bodyLen);
      // 4 bytes		CLIENTVERSION  00 00 00 c8
      bytes[0] = 0;
      bytes[1] = 0;
      bytes[2] = 0;
      bytes[3] = 0xc8;
      // 4 bytes		cmdId	probuf的id
      bytes[4] = (cmdId >> 24) & 0xff;
      bytes[5] = (cmdId >> 16) & 0xff;
      bytes[6] = (cmdId >> 8) & 0xff;
      bytes[7] = cmdId & 0xff;
      // 4 bytes		seq		序列号
      bytes[8] = (seq >> 24) & 0xff;
      bytes[9] = (seq >> 16) & 0xff;
      bytes[10] = (seq >> 8) & 0xff;
      bytes[11] = seq & 0xff;
      // 4 bytes     bodyLen body大小
      bytes[12] = (bodyLen >> 24) & 0xff;
      bytes[13] = (bodyLen >> 16) & 0xff;
      bytes[14] = (bodyLen >> 8) & 0xff;
      bytes[15] = bodyLen & 0xff;
      // body
      if (bodyLen > 0) {
        for (let i = 0; i < bodyLen; ++i) {
          bytes[16 + i] = bodyBytes[i];
        }
      }

      return bytes;
    },
    //投注
    betClick(betIndex, betNum, hitNum) {
      let data = this.getbodyBytes($root.FishCmd.bet, {
        userId: this.userId,
        betIndex: betIndex,
        betNum: betNum,
        hitNum: hitNum
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1290, data);
      this.websocket.send(result);
    },
    //节流
    throttle(item) {
      this.throttlenowTime = Date.now();
      if (
        this.throttleLastTime &&
        this.throttlenowTime - this.throttleLastTime < this.throttleDelay
      ) {
        clearTimeout(this.throttleTimer);
        this.throttleDelay = setTimeout(() => {});
      } else {
        this.throttleLastTime = this.throttlenowTime;
        this.throttleArr.push(item);
      }
    },
    clickBets(item) {
      if (item.grade > this.balance) {
        layer.open({
          content: "余额不足",
          skin: "msg",
          time: 2
        });
        return;
      }
      if (this.step == 1) {
        item.double++;
        console.log(item);
        this.balance = this.balance - item.grade;
        this.betClick(item.betIndex, item.grade, item.double);
      } else {
        layer.open({
          content: "垂钓过程中不能竞猜哦",
          skin: "msg",
          time: 2
        });
      }
    },
    //读取excel数据
    // readExcel() {
    //   axios.get("/api/app/data/Recharge").then(res => {
    //     if (res.status == 200) {
    //       let key = res.data.keys;
    //       let value = res.data.values;
    //       let result = this.JSONParse(key, value);

    //     }
    //   });
    // },
    //根据key value 转成json 字符串
    JSONParse(key, value) {
      let Result = [];

      for (let i = 0; i < value.length; i++) {
        //key
        let object = {};
        key.forEach((item, index) => {
          object[item] = value[i][index];
          // console.log("key", object[item]);
          // console.log("value", value[i][index]);
        });
        Result.push(object);
      }

      return Result;
    },
    openRule() {
      this.ruleRecordState = true;
      this.ruleStatus = true;
      this.getmyCommission();
    },
    closeRuleRecord(e) {
      if (
        (this.$refs.ruleBox && !this.$refs.ruleBox.contains(e.target)) ||
        (this.$refs.RecordBox && !this.$refs.RecordBox.contains(e.target))
      ) {
        this.ruleRecordState = false;
        this.ruleStatus = false;
        this.recordStatus = false;
      }
    },
    getUserHead(logoTime, thirdIconurl, userId) {
      if (logoTime > 0) {
        return this.userImgBaseUrl + userId;
      } else if (thirdIconurl) {
        if (thirdIconurl.startsWith("http")) {
          return thirdIconurl;
        } else {
          return this.userImgBaseUrl2 + thirdIconurl + ".jpg";
        }
      }
    },
    openRecord() {
      this.ruleRecordState = true;
      this.recordStatus = true;
      this.getRecoreDate();
    },
    openStake() {
      this.stakeStatus = !this.stakeStatus;
    },

    defaultFish1() {
      console.log(this.$refs.blueCat);
      let width = this.$refs.blueCat.clientWidth * 2;
      let height = this.$refs.blueCat.clientHeight * 2;
      let canvas1 = this.$refs.canvas1;
      let that = this;
      canvas1.width = width;
      canvas1.height = height;
      let ctx = canvas1.getContext("2d");
      console.log(canvas1);
      let image = new Image();
      image.width = width;
      image.height = height;
      image.src = "https://coscdn.suresvip.com/app/html/smashEgg/default1.png";
      console.log(image);
      ctx.clearRect(0, 0, canvas1.width, canvas1.height);
      ctx.drawImage(image, 0, 0, width, height);
    },
    clearIntervalAll() {
      this.timer = null;
      clearInterval(this.timer);
    },
    defaultAnimation3(){
        let width = this.$refs.seaComp.clientWidth * 2;
      let height = this.$refs.seaComp.clientHeight * 2;
       let sea = this.$refs.sea;
        sea.width = width;
      sea.height = height;
       let ctx = sea.getContext("2d");
       let index=0;

        window.clearInterval(this.timer3);
        this.timer3=setInterval(() => {
           if(index==50){
              index=0;
            }
            ctx.clearRect(0, 0, sea.width, sea.height);
             ctx.drawImage(
            this.seaImgArr[index],
            0,
            0,
            width,
            height
          )
             index++;
        },60)

    },
    defaultAnimation() {
      let width = this.$refs.blueCat.clientWidth * 2;
      let height = this.$refs.blueCat.clientHeight * 2;
      let canvas1 = this.$refs.canvas1;
      let that = this;
      canvas1.width = width;
      canvas1.height = height;
      let ctx = canvas1.getContext("2d");
      this.defaultblueIndex = 0;
      this.defaultblueIndex2 = 0;
      this.defaultblueIndex3 = 0;
      this.defaultblueIndex4 = 0;
      this.defaultblueIndex5 = 0;
      window.clearInterval(this.timer);
      this.timer = setInterval(() => {
        ctx.clearRect(0, 0, canvas1.width, canvas1.height);
        if (this.defaultActive == 0) {
          //默认
          if (this.defaultblueIndex == 38) {
            this.defaultblueIndex = 0;
          }
          ctx.drawImage(
            this.defaultBlueAll[this.defaultblueIndex],
            0,
            0,
            width,
            height
          );
          this.defaultblueIndex++;
        } else if (this.defaultActive == 1) {
          //甩
          //甩杆
          if (this.defaultblueIndex2 >= 39) {
            // this.defaultredIndex2 = 0;//3种状态1，过渡到等待，2过渡到上钩，3过渡到没鱼
            if (this.fishStatus == 1) {
              //等待
              this.defaultActive = 2;
              this.defaultblueIndex3 = 0;
            } else if (this.fishStatus == 2) {
              //上钩
              this.defaultActive = 3;
              this.defaultblueIndex4 = 0;
            } else if (this.fishStatus == 3) {
              //没鱼
              this.defaultActive = 4;
              this.defaultblueIndex5 = 0;
            }
            this.defaultblueIndex2=0;
          }
          ctx.drawImage(
            this.swingblueImg[this.defaultblueIndex2],
            0,
            0,
            width,
            height
          );
          this.defaultblueIndex2++;
        } else if (this.defaultActive == 2) {
          //等待
          if (this.defaultblueIndex3 >= 38) {
            if (this.fishStatus == 1) {
              //等待
              this.defaultActive = 2;
              this.defaultblueIndex3 = 0;
            } else if (this.fishStatus == 2) {
              //上钩
              this.defaultActive = 3;
              this.defaultblueIndex4 = 0;
            } else if (this.fishStatus == 3) {
              //没鱼
              this.defaultActive = 4;
              this.defaultblueIndex5 = 0;
            }
            this.defaultblueIndex3=0;
          }
          ctx.drawImage(
            this.waitblueImg[this.defaultblueIndex3],
            0,
            0,
            width,
            height
          );
          this.defaultblueIndex3++;
        } else if (this.defaultActive == 3) {
          //上钩
          if (this.defaultblueIndex4 == 20) {
            this.currentblueNum++;
          }

          if (this.defaultblueIndex4 >= 38) {
            if (this.fishStatus == 1) {
              //等待
              this.defaultActive = 2;
              this.defaultblueIndex3 = 0;
            } else if (this.fishStatus == 2) {
              //上钩
              this.defaultActive = 3;
              this.defaultblueIndex4 = 0;
            } else if (this.fishStatus == 3) {
              //没鱼
              this.defaultActive = 4;
              this.defaultblueIndex5 = 0;
            }
            this.defaultblueIndex4=0;
          }
          ctx.drawImage(
            this.hookedupblueImg[this.defaultblueIndex4],
            0,
            0,
            width,
            height
          );
          this.defaultblueIndex4++;
        } else if (this.defaultActive == 4) {
          //未上钩
          if (this.defaultblueIndex5 >= 38) {
            if (this.fishStatus == 1) {
              //等待
              this.defaultActive = 2;
              this.defaultblueIndex3 = 0;
            } else if (this.fishStatus == 2) {
              //上钩
              this.defaultActive = 3;
              this.defaultblueIndex4 = 0;
            } else if (this.fishStatus == 3) {
              //没鱼
              this.defaultActive = 4;
              this.defaultblueIndex5 = 0;
            }
            this.defaultblueIndex5=0;
          }
          ctx.drawImage(
            this.nohookedupblueImg[this.defaultblueIndex5],
            0,
            0,
            width,
            height
          );
          this.defaultblueIndex5++;
        }
      }, 60);
    },
    defaultAnimation2() {
      let width = this.$refs.redCat.clientWidth * 2;
      // let resultOne = this.$refs.resultOne;
      // let DetailedList = this.$refs.DetailedList;
      let height = this.$refs.redCat.clientHeight * 2;
      let canvas1 = this.$refs.canvas2;
      let that = this;
      canvas1.width = width;
      canvas1.height = height;
      let ctx = canvas1.getContext("2d");
      this.defaultredIndex = 0;
      this.defaultredIndex2 = 0;
      this.defaultredIndex3 = 0;
      this.defaultredIndex4 = 0;
      this.defaultredIndex5 = 0;
      window.clearInterval(this.timer2);
      this.timer2 = setInterval(() => {
        ctx.clearRect(0, 0, canvas1.width, canvas1.height);
        if (this.defaultActive2 == 0) {
          if (this.defaultredIndex == 38) {
            this.defaultredIndex = 0;
          }
          ctx.drawImage(
            this.defaultRedAll[this.defaultredIndex],
            0,
            0,
            width,
            height
          );
          this.defaultredIndex++;
        } else if (this.defaultActive2 == 1) {
          //甩
          if (this.defaultredIndex2 >= 39) {
            this.defaultredIndex3 = 0;

            // this.defaultredIndex2 = 0;//3种状态1，过渡到等待，2过渡到上钩，3过渡到没鱼
            if (this.fishStatus2 == 1) {
              //等待
              this.defaultActive2 = 2;
              this.defaultredIndex3 = 0;
            } else if (this.fishStatus2 == 2) {
              //上钩
              this.defaultActive2 = 3;
              this.defaultredIndex4 = 0;
            } else if (this.fishStatus2 == 3) {
              //没鱼
              this.defaultActive2 = 4;
              this.defaultredIndex5 = 0;
            }
          }
          ctx.drawImage(
            this.swingredImg[this.defaultredIndex2],
            0,
            0,
            width,
            height
          );
          this.defaultredIndex2++;
        } else if (this.defaultActive2 == 2) {
          //等待
          if (this.defaultredIndex3 >= 38) {
            if (this.fishStatus2 == 1) {
              //等待
              this.defaultredIndex2 = 2;
              this.defaultredIndex3 = 0;
            } else if (this.fishStatus2 == 2) {
              //上钩
              this.defaultActive2 = 3;
              this.defaultredIndex4 = 0;
            } else if (this.fishStatus2 == 3) {
              //没鱼
              this.defaultActive2 = 4;
              this.defaultredIndex5 = 0;
            }
          }
          ctx.drawImage(
            this.waitredImg[this.defaultredIndex3],
            0,
            0,
            width,
            height
          );
          this.defaultredIndex3++;
        } else if (this.defaultActive2 == 3) {
          //上钩
          if (this.defaultredIndex4 == 20) {
            this.currentredNum++;
          }
          if (this.defaultredIndex4 >= 38) {
            // this.defaultActive2 = 1;
            // this.defaultredIndex2 = 0;
            // this.defaultredIndex4 = 0;
            if (this.fishStatus2 == 1) {
              //等待
              this.defaultActive2 = 2;
              this.defaultredIndex3 = 0;
            } else if (this.fishStatus2 == 2) {
              //上钩
              this.defaultActive2 = 3;
              this.defaultredIndex4 = 0;
            } else if (this.fishStatus2 == 3) {
              //没鱼
              this.defaultActive2 = 4;
              this.defaultredIndex5 = 0;
            }
          }
          ctx.drawImage(
            this.hookedupredImg[this.defaultredIndex4],
            0,
            0,
            width,
            height
          );

          this.defaultredIndex4++;
        } else if (this.defaultActive2 == 4) {
          if (this.defaultredIndex5 >= 38) {
            if (this.fishStatus2 == 1) {
              //等待
              this.defaultActive2 = 2;
              this.defaultredIndex3 = 0;
            } else if (this.fishStatus2 == 2) {
              //上钩
              this.defaultActive2 = 3;
              this.defaultredIndex4 = 0;
            } else if (this.fishStatus2 == 3) {
              //没鱼
              this.defaultActive2 = 4;
              this.defaultredIndex5 = 0;
            }
            this.defaultredIndex5 = 0;
          }
          ctx.drawImage(
            this.nohookedupredImg[this.defaultredIndex5],
            0,
            0,
            width,
            height
          );
          this.defaultredIndex5++;
        }
      }, 60);
    },
     preloadimages3(arr) {
      var newimages = [],
        loadedimages = 0;
      var arr = typeof arr != "object" ? [arr] : arr;
      let that = this;
      function imageloadpost() {
        loadedimages++;

        if (loadedimages == arr.length) {
          let j = 0;
          for (let i = 0; i < newimages.length; i++) {
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/sea/sea"
              )
            ) {
              j++;
              
              that.seaImgArr.push(newimages[i]);
              if (j == 50) {
                that.defaultAnimation3();
              }
            }
            
          }
        }
      }
      for (var i = 0; i < arr.length; i++) {
        newimages[i] = new Image();
        newimages[i].src =
          "https://coscdn.suresvip.com/app/html/images/Fish/sea/" +
          arr[i] +
          ".png";
        newimages[i].onload = function() {
          imageloadpost();
        };
        newimages[i].onerror = function() {
          imageloadpost();
        };
      }
    },
    preloadimages(arr) {
      var newimages = [],
        loadedimages = 0;
      var arr = typeof arr != "object" ? [arr] : arr;
      let that = this;
      function imageloadpost() {
        loadedimages++;

        if (loadedimages == arr.length) {
          let j = 0;
          for (let i = 0; i < newimages.length; i++) {
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/blueCat/defaultBlueCat"
              )
            ) {
              j++;
              that.defaultBlueAll.push(newimages[i]);
              // if (j == 40) {
              //   that.defaultAnimation();
              // }
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/blueCat/swingblue"
              )
            ) {
              that.swingblueImg.push(newimages[i]);
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/blueCat/waitblueCat"
              )
            ) {
              that.waitblueImg.push(newimages[i]);
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/blueCat/hookedupblue"
              )
            ) {
              that.hookedupblueImg.push(newimages[i]);
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/blueCat/nohookedupblue"
              )
            ) {
              that.nohookedupblueImg.push(newimages[i]);
            }
          }
        }
      }
      for (var i = 0; i < arr.length; i++) {
        newimages[i] = new Image();
        newimages[i].src =
          "https://coscdn.suresvip.com/app/html/images/Fish/blueCat/" +
          arr[i] +
          ".png";
        newimages[i].onload = function() {
          imageloadpost();
        };
        newimages[i].onerror = function() {
          imageloadpost();
        };
      }
    },
    preloadimages2(arr) {
      var newimages = [],
        loadedimages = 0;
      var arr = typeof arr != "object" ? [arr] : arr;
      let that = this;
      function imageloadpost() {
        loadedimages++;
        that.loadingNumber += 0.5;
        if (loadedimages == arr.length) {
          console.log(loadedimages);
          let j = 0;
          for (let i = 0; i < newimages.length; i++) {
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/redCat/defaultRedcat"
              )
            ) {
              that.defaultRedAll.push(newimages[i]);
              // if (j == 40) {
              //   console.log(666);
              //   that.defaultAnimation2();
              //   // that.forSetAnimate(that.getAllArr);
              //   layer.closeAll();
              // }
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/redCat/swingred"
              )
            ) {
              that.swingredImg.push(newimages[i]);
            } //waitredCat1
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/redCat/waitredCat"
              )
            ) {
              that.waitredImg.push(newimages[i]);
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/redCat/hookedupred"
              )
            ) {
              that.hookedupredImg.push(newimages[i]);
            }
            if (
              newimages[i].src.startsWith(
                "https://coscdn.suresvip.com/app/html/images/Fish/redCat/nohookedupred"
              )
            ) {
              that.nohookedupredImg.push(newimages[i]);
            }
          }
        }
      }
      for (var i = 0; i < arr.length; i++) {
        newimages[i] = new Image();
        newimages[i].src =
          "https://coscdn.suresvip.com/app/html/images/Fish/redCat/" +
          arr[i] +
          ".png";
        newimages[i].onload = function() {
          imageloadpost();
        };
        newimages[i].onerror = function() {
          imageloadpost();
        };
      }
    },
    //活动倒计时
    timerAllDowm() {
      let status = false;
      window.clearInterval(this.Activetimer);
      this.Activetimer = setInterval(() => {
        if (this.stepRemain && this.stepRemain > 0) {
          // if (this.step == 1) {
          //   //等待
          //   if (!status) {
          //     this.defaultActive = 0;
          //     this.defaultActive2 = 0;

          //   }
          // } else if (this.step == 2) {
          //   //钓鱼
          //   if (status) {
          //     this.defaultActive = 2;
          //     this.defaultActive2 = 2;
          //     status = false;
          //   }
          // } else if (this.step == 3) {
          //   if (status) {
          //     this.defaultActive = 0;
          //     this.defaultActive2 = 0;
          //     this.resultState = true;
          //     status = false;
          //   }
          //   //中奖
          // }

          this.stepRemain--;
        } else {
          window.clearInterval(this.Activetimer);
          this.infoState = false;
          if (this.step == 1) {
            // this.getMyBeteDetail();
            // this.step = 2;

            // this.RecodeState=true;
            this.defaultActive = 1;
            this.defaultActive2 = 1;
            // this.step = 2;
            // this.websocket.send(this.enterData());
          } else if (this.step == 2) {
            // this.step = 3;
            //获取投注详情和投注结果
            this.RecodeState = false;
            // this.websocket.send(this.enterData());
          } else if (this.step == 3) {
            // this.step = 1;
            this.bettingState = false;
            this.resultState = false;
            // this.websocket.send(this.enterData());
          }
        }
      }, 1000);
    },
    getSignParam(sortKeys, data) {
      let ret = null;
      for (let i = 0, l = sortKeys.length; i < l; ++i) {
        const k = sortKeys[i];

        //空字符串不参与加密
        if (data[k] === "") continue;

        if (ret != null) {
          ret += "&";
        } else {
          ret = "";
        }
        ret += k + "=" + data[k];
      }
      return ret;
    },
    getSignParam2(sortKeys, data) {
      let ret = null;
      for (let i = 0, l = sortKeys.length; i < l; ++i) {
        const k = sortKeys[i];

        if (ret != null) {
          ret += "&";
        } else {
          ret = "";
        }
        ret += k + "=" + encodeURIComponent(data[k]);
      }
      return ret;
    },
    websocketstart() {
      let app_key = "821F422DE2E9CFA9A946F0EAE1D37964";
      let data = {
        channelId: "official",
        deviceId: "DAFFC90A-544B-3C64-A331-E9D05E399EDB",
        deviceType: 1,
        imei: 865166028299959,
        mac: "00:81:67:3B:90:BA",
        model: "android r7plus",
        version: "3.1.2",
        release: "5.1.1"
      };
      const sortKeys = Object.keys(data).sort();
      const signParam = this.getSignParam(sortKeys, data);
      const signParam2 = this.getSignParam2(sortKeys, data);

      const signData = MD5(signParam + app_key).toUpperCase();
      const params = signParam2 + "&sign=" + signData;
      this.getWsUrl(params);
    },
    getWsUrl(params) {
      //http://api.suresvip.com/Api/AppInit.do//
      this.$http
        .get("https://outtest.api.suresvip.com/Api/AppInit.do?" + params)
        .then(res => {
          let wsuri = res.data.apiServer;
          wsuri = wsuri.replace("http://", "wss://");
          wsuri = wsuri.replace("https://", "wss://");
          wsuri = wsuri.replace(".api.", ".applogic.");
          wsuri = `${wsuri}/${res.data.serverId}`;
          console.log(wsuri);
          //let wsuri = `wss://${res.data.logicHost}:${res.data.h5Port}`; //ws://192.168.101.250:8082
          this.initWebSocket(wsuri);
        });
    },
    //初始化websocket
    initWebSocket(wsuri) {
      // const wsuri = "ws://192.168.101.250:8082"; //ws地址
      this.websocket = new WebSocket(wsuri);
      this.websocket.binaryType = "arraybuffer";
      this.websocket.onopen = this.websocketonopen;
      this.websocket.onerror = this.websocketonerror;
      this.websocket.onmessage = this.websocketonmessage;
      this.websocket.onclose = this.websocketclose;
    },
    websocketonopen(agentData) {
      console.log("WebSocket连接成功");
      if (this.websocket.readyState === 1) {
        //enterDate开启心跳
        this.startHeart();
        this.websocket.send(this.enterData());
      }
    },
    leave() {
      let data = this.getbodyBytes($root.FishCmd.leave, {
        userId: this.userId
      });
      let result = this.getSendUint8Array(this.Interfacenumber, 1289, data);
      this.websocket.send(result);
    },
    //获取记录
    getRecord() {
      let result = this.getbodyBytes($root.FishCmd.enter, {
        userId: this.userId
      });
    },
    enterData() {
      let result = this.getbodyBytes($root.FishCmd.enter, {
        userId: this.userId
      });
      let userInfos = this.getSendUint8Array(
        this.Interfacenumber,
        1288,
        result
      );
      return userInfos;
    },
    onBroadcastCallJS(cmdid, params) {
      console.log("onBroadcastCallJS阶段", cmdid, params);
      if (cmdid == 3171) {
        this.step = params.step;
        console.log("onBroadcastCallJS阶段", params.step, this.step);
        if (this.step == 1) {
          //等待
          this.resultState = false;
          this.defaultblueIndex = 0;
          this.defaultredIndex = 0;
          this.defaultActive = 0;
          this.defaultActive2 = 0;
        } else if (this.step == 3) {
          //开奖
          this.defaultblueIndex = 0;
          this.defaultredIndex = 0;
          this.defaultActive = 0;
          this.defaultActive2 = 0;
          this.resultState = true;
        }
        this.stepRemain = parseInt(params.stepRemain / 1000);
        if (params.roundData && this.step == 2) {
          this.blueNum = params.roundData.blueNum;
          this.redNum = params.roundData.redNum;
          this.bluebarsNumber = params.roundData.blueDatas;
          this.redbarsNumber = params.roundData.redDatas;
          let userTime = (
            (this.stepTime * 1000 - params.stepRemain) /
            1000
          ).toFixed(1);
          if (userTime > 0.2) {
            let bluebarTime = 0;
            let redbarTime = 0;
            let blueI = 0;
            let redI = 0;
            console.log("this.bluebarsNumber", this.bluebarsNumber);
            if (this.bluebarsNumber) {
              for (let j = 0; j < this.bluebarsNumber.length; j++) {
                bluebarTime += Math.abs(this.bluebarsNumber[j]);
                if (bluebarTime <= userTime) {
                  if (this.bluebarsNumber[j] >= 0) {
                    this.currentblueNum++;
                  } else {
                    blueI = j;
                    break;
                  }
                }
              }
              this.bluebarsNumber = this.bluebarsNumber.splice(
                blueI,
                this.bluebarsNumber.length
              );
            }
            console.log(44);
            if (this.redbarsNumber) {
              for (let i = 0; i < this.redbarsNumber.length; i++) {
                redbarTime += Math.abs(this.redbarsNumber[i]);
                if (redbarTime <= userTime) {
                  if (this.redbarsNumber[i] >= 0) {
                    this.currentredNum++;
                  }
                  this.redbarsNumber = this.redbarsNumber.splice(
                    i,
                    this.redbarsNumber.length
                  );
                } else {
                  redI = i;
                  break;
                }
              }
              this.redbarsNumber = this.redbarsNumber.splice(
                redI,
                this.redbarsNumber.length
              );
              console.log("后", this.bluebarsNumber);
            }
          }
          this.goFishNext1(0);
          this.goFishNext2(0);
          // this.goFish(this.bluebarsNumber);
          // this.goFish2(this.redbarsNumber);
        }
        console.log(params);
      }
    },
    getbodyBytes(proto, data) {
      let message = proto.create(data);
      const buffer = proto.encode(message).finish();
      const buffers = new ArrayBuffer(buffer.length);
      const result = Uint8Array.from(buffer);
      return result;
    },
    headData() {
      let data = this.getbodyBytes($root.UserCmd.heartBeat, {});
      let result = this.getSendUint8Array(this.Interfacenumber, 1164, data);
      this.websocket.send(result);
    },
    //开启心跳
    startHeart() {
      this.heartTimeout && window.clearInterval(this.heartTimeout);
      this.heartTimeout = setTimeout(() => {
        if (this.websocket.readyState === 1) {
          //发送
          this.headData();
        } else {
          //断线重连
          this.reconnect();
        }
      }, this.heartTimer);
    },
    websocketonerror() {
      //错误
      console.error("WebSocket连接发生错误");
      this.reconnect();
    },

    websocketonmessage(e) {
      //数据接收
      console.log("e", e.data);
      let bytes = new Uint8Array(e.data);

      let body = null;
      let cmdId =
        ((bytes[4] & 0xff) << 24) |
        ((bytes[5] & 0xff) << 16) |
        ((bytes[6] & 0xff) << 8) |
        (bytes[7] & 0xff);
      //            4 bytes		seq		序列号
      let seq =
        ((bytes[8] & 0xff) << 24) |
        ((bytes[9] & 0xff) << 16) |
        ((bytes[10] & 0xff) << 8) |
        (bytes[11] & 0xff);
      let state = ((bytes[18] & 0xff) << 8) | (bytes[19] & 0xff);
      //                    body
      this.startHeart();
      console.log(cmdId, state, seq);
      if (cmdId == 256) {
        layer.open({
          content: "今日下注额度已超上限",
          skin: "msg",
          time: 2
        });
        return;
      } else if (cmdId == 257) {
        layer.open({
          content: "贡献值不足",
          skin: "msg",
          time: 2
        });
        return;
      } else if (cmdId == 258) {
        layer.open({
          content: "非下注时间不能下注",
          skin: "msg",
          time: 2
        });
        return;
      } else if (cmdId == 3161) {
        if (state == 1) {
          let proto = $root.FishResult.FishData;
          const reader = $Reader.create(bytes);
          reader.skip(20);
          body = proto.decode(reader);
          this.balance = body.balance;
          this.step = body.step;
          if (this.step == 1) {
            //等待
            this.resultState = false;
            this.defaultblueIndex = 0;
            this.defaultredIndex = 0;
            this.defaultActive = 0;
            this.defaultActive2 = 0;
          } else if (this.step == 2) {
            //钓鱼
            this.defaultblueIndex = 0;
            this.defaultredIndex = 0;
            this.defaultActive = 2;
            this.defaultActive2 = 2;
          } else if (this.step == 3) {
            //开奖
            this.defaultblueIndex = 0;
            this.defaultredIndex = 0;
            this.defaultActive = 0;
            this.defaultActive2 = 0;
            this.resultState = true;
          }
          this.stepRemain = parseInt(body.stepRemain / 1000);
          this.timerAllDowm();
          this.betResults = body.betResults;
          if (body.user && body.user.nickName) {
            this.nickName = decodeURIComponent(body.user.nickName);
          }
          this.headportrait = this.getUserHead(
            body.user.logoTime,
            body.user.thirdIconurl,
            body.user.userId
          );
          this.MyBetData = body.allBetData.myBetData.betDatas;
          if (body.roundData) {
            this.bluebarsNumber = body.roundData.blueDatas;
            this.redbarsNumber = body.roundData.redDatas;
            console.log("body.roundData.blueDatas", body.roundData.blueDatas);
            console.log(" this.bluebarsNumber", this.bluebarsNumber);
            console.log("前", this.bluebarsNumber);
            let userTime = (
              (this.stepTime * 1000 - body.stepRemain) /
              1000
            ).toFixed(1);
            if (userTime > 0.2) {
              let bluebarTime = 0;
              let redbarTime = 0;
              let blueI = 0;
              let redI = 0;
              if (this.bluebarsNumber) {
                for (let j = 0; j < this.bluebarsNumber.length; j++) {
                  bluebarTime += Math.abs(this.bluebarsNumber[j]);
                  if (bluebarTime <= userTime + 1) {
                    if (this.bluebarsNumber[j] >= 0) {
                      this.currentblueNum++;
                    } else {
                      blueI = j;
                      break;
                    }
                  }
                }
                this.bluebarsNumber = this.bluebarsNumber.splice(
                  blueI,
                  this.bluebarsNumber.length
                );
              }
              if (this.redbarsNumber) {
                for (let i = 0; i < this.redbarsNumber.length; i++) {
                  redbarTime += Math.abs(this.redbarsNumber[i]);
                  if (redbarTime <= userTime + 1) {
                    if (this.redbarsNumber[i] >= 0) {
                      this.currentredNum++;
                    }
                    this.redbarsNumber = this.redbarsNumber.splice(
                      i,
                      this.redbarsNumber.length
                    );
                  } else {
                    redI = i;
                    break;
                  }
                }
                this.redbarsNumber = this.redbarsNumber.splice(
                  redI,
                  this.redbarsNumber.length
                );
              }
            }
            console.log("后", this.bluebarsNumber);
            this.blueNum = body.roundData.blueNum;
            this.redNum = body.roundData.redNum;
            this.goFishNext1(0);
            this.goFishNext2(0);
            // this.goFish(this.bluebarsNumber);
            // this.goFish2(this.redbarsNumber);
          }
          this.blueCatNum = body.allBetData.betDatas[1].total;
          this.flagCatNum = body.allBetData.betDatas[0].total;
          this.redCatNum = body.allBetData.betDatas[2].total;
          let flagDate = body.allBetData.myBetData.betDatas[0];
          let blueDate = body.allBetData.myBetData.betDatas[1];
          let redDate = body.allBetData.myBetData.betDatas[2]; //myBetData
          flagDate.betCounts.forEach((item, index) => {
            this.dateflagDate[index].double = item;
          });
          blueDate.betCounts.forEach((item, index) => {
            this.dateBlueDate[index].double = item;
          });
          redDate.betCounts.forEach((item, index) => {
            this.dateredDate[index].double = item;
          });
        }
      } else if (cmdId == 3162) {
      } else if (cmdId == 3163) {
        this.RecodeState = true;
        let proto = $root.FishResult.AllBetData;
        const reader = $Reader.create(bytes);
        reader.skip(20);
        body =proto.decode(reader);
      this.myBetData=body.myBetData.betDatas;
       console.log(body.myBetData.betDatas)
        this.flagCatNum=body.betDatas[0].total;
         this.blueCatNum=body.betDatas[1].total;
          this.redCatNum=body.betDatas[2].total;
      } else if (cmdId == 3168) {
        let proto = $root.FishResult.MyBetLog;
        const reader = $Reader.create(bytes);
        reader.skip(20);
        body = proto.decode(reader);
        this.logsDetail = body.logs;
      } else if (cmdId == 2015) {
        let proto = $root.CommonResult.IntResult;
        const reader = $Reader.create(bytes);
        reader.skip(20);
        this.Diamonds = proto.decode(reader).data + "钻石";
      } else if (cmdId == 3164) {
        let proto = $root.FishResult.MyBetData;
        const reader = $Reader.create(bytes);
        reader.skip(20);
        this.MyBetData = proto.decode(reader).betDatas;
      } else if (cmdId == 3166) {
        //获取所有投注信息
        let proto = $root.FishResult.UserBetDetail;
        const reader = $Reader.create(bytes);
        reader.skip(20);
        body = proto.decode(reader).betDatas;
        this.userBase = [];
        for (let i = 0; i < body.length; i++) {
          let sum = 0;
          body[i].betTotal.forEach((item, index) => {
            sum = sum + item;
            body[i].users[index].betTotal = item;
            body[i].users[index].userHead = this.getUserHead(
              body[i].users[index].logoTime,
              body[i].users[index].thirdIconurl,
              body[i].users[index].userId
            );
          });
          //userHead

          body[i].users.sum = sum;
          this.userBase.push(body[i].users);

         
        }
          console.log(this.userBase)
         this.blueCatNum=this.userBase[1].sum;
          this.flagCatNum=this.userBase[0].sum;
          this.redCatNum=this.userBase[2].sum;
      } else if (cmdId == 257) {
        this.Vulgar = true;
      }
    },
    websocketsend(agentData) {
      //数据发送
    },
    websocketclose(e) {
      //关闭
      console.log("connection closed (" + e.code + ")");
    },
    reconnect() {
      this.timeoutnum && clearTimeout(this.timeoutnum);
      this.timeoutnum = setTimeout(() => {
        if (this.wsNum > 0) {
          this.websocketstart();
          this.wsNum--;
        }
      }, 4000);
    },
    //读取表
    readExcel() {
      axios.get("/api/app/data/CS_FishConfig?t=3").then(res => {
        if (res.status == 200) {
          let key = res.data.keys;
          let value = res.data.values;
          let result = this.JSONParse(key, value);
          this.stepTime = result[3].value.playTime;
          this.versionArr = result[4].value.versions;
          this.chanelsArr = result[4].value.channels;
          this.open = result[5].value.open;
        }
      });
    }
  },
  computed: {},
  mounted() {
    window.onBroadcastCallJS = this.onBroadcastCallJS;
    this.readExcel();
  }
};
</script>

<style lang="scss" scoped>
.catFishing {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
  background: #009ae8;
  .ruleRecordModule {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0);
    z-index: 300;
    .ruleBox,
    .RecordBox {
      width: 750px;
      height: 854px;
      position: absolute;
      left: 0;
      bottom: 0;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/ruleBg.png")
        no-repeat center center;
      background-size: 100%;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      h3 {
        height: 35px;
        font-size: 36px;
        font-family: Source Han Sans CN;
        font-weight: bold;
        color: rgba(145, 84, 23, 1);
        margin: 35px auto;
      }
      p {
        width: 658px;
        // height: 65px;
        font-size: 24px;
        font-family: PingFang SC;
        font-weight: 500;
        text-align: left;
        color: rgba(202, 131, 61, 1);
        margin: 10px auto;
      }
      .Commission {
        width: 658px;
        height: 80px;
        margin: 10px auto;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        .info {
          font-size: 30px;
          font-family: PingFang SC;
          font-weight: bold;
          color: rgba(145, 84, 23, 1);
          margin-right: 20px;
        }
        input {
          width: 240px;
          height: 70px;
          border: 1px solid rgba(163, 101, 39, 1);
          border-radius: 10px;
          background: #ffeeb9;
          padding-left: 15px;
          box-sizing: border-box;
        }
        button {
          width: 128px;
          height: 80px;
          border: none;
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/ReceiveBtn.png")
            no-repeat center center;
          background-size: 100%;
        }
      }
      .yaoqinginfo {
        width: 120px;
        height: 32px;
        font-size: 24px;
        font-family: Source Han Sans CN;
        font-weight: 500;
        color: rgba(145, 84, 23, 1);
        margin: 40px auto;
        position: relative;
        &::before {
          display: block;
          content: "";
          position: absolute;
          left: -250px;
          top: 50%;
          width: 240px;
          height: 2px;
          background: rgba(163, 101, 39, 1);
        }
        &::after {
          display: block;
          content: "";
          position: absolute;
          left: 100px;
          top: 50%;
          width: 240px;
          height: 2px;
          background: rgba(163, 101, 39, 1);
        }
      }
      .Invitation {
        width: 600px;
        height: 150px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        align-content: space-between;
        li {
          width: 110px;
          height: 150px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          align-items: center;
          img {
            width: 110px;
            height: 110px;
          }
          p {
            width: 110px;
            text-align: center;
            font-size: 24px;
            font-family: PingFang SC;
            font-weight: 500;
            color: rgba(145, 84, 23, 1);
          }
        }
      }
    }
    .RecordBox {
      .RecordContent {
        width: 690px;
        height: 745px;
        // border: 1px solid #f00;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center;
        align-content: flex-start;
        overflow-y: scroll;
        li {
          width: 100%;
          height: 105px;
          border-bottom: 2px solid rgba(255, 255, 255, 0.5);
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          flex-shrink: 0;

          .leftInfo,
          .rightInfo {
            width: 220px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
            align-content: center;
            .winName {
              font-size: 26px;
              font-family: PingFang SC;
              font-weight: 500;
              color: rgba(145, 84, 23, 1);
            }
            .touru {
              font-size: 22px;
              font-family: PingFang SC;
              font-weight: 500;
              color: rgba(202, 131, 61, 1);
              img {
                width: 40px;
                height: 32px;
              }
            }
          }
          .rightInfo {
            justify-content: center;
            align-items: flex-end;
            align-content: center;
            .winNumber {
              font-size: 30px;
              font-family: PingFang SC;
              font-weight: bold;
              color: rgba(145, 84, 23, 1);
            }
            .timer {
              font-size: 22px;
              font-family: PingFang SC;
              font-weight: 500;
              color: rgba(202, 131, 61, 1);
            }
          }
        }
      }
    }
  }
  .fixedBox,
  .resultModule,
  .noVulgars {
    position: Fixed;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 500;
    .logoDiv {
      position: relative;
      top: 450px;
      left: 50%;
      width: 338px;
      height: 246px;
      transform: translate(-50%, -50%);
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/logo.png")
        no-repeat center center;
      background-size: 100%;
    }
    .loadPressBox {
      position: relative;

      top: 350px;
      left: 50%;
      transform: translateX(-50%);
      width: 407px;
      height: 42px;
      .loadPressDiv {
        height: 100%;
        width: 100%;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/loadpress.png")
          no-repeat center center;
        background-size: 100% 100%;
        p {
          color: #fff;
        }
      }
    }
    .loadAnimate {
      color: #fff;
      font-size: 34px;
      font-weight: Bold;
      position: relative;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      align-content: center;
      line-height: 34px;
      top: 360px;
      .loadspotBox {
        width: 42px;
        height: 24px;
        margin-top: 25px;
        margin-left: 5px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        align-content: center;
      }
      .loadspot {
        display: inline-block;
        width: 8px;
        height: 8px;
        background: #fff;
        border-radius: 50%;
        animation: load 1.04s ease infinite;
      }
      @keyframes load {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      .loadspot:nth-child(1) {
        animation-delay: 0.13s;
      }
      .loadspot:nth-child(2) {
        animation-delay: 0.26s;
      }
      .loadspot:nth-child(3) {
        animation-delay: 0.39s;
      }
    }
  }
  .noVulgars {
    .info {
      margin-top: 360px;
      color: #fff;
    }
  }
  .resultModule {
    .logoDiv {
      top: 240px;
    }
    .buleResultBox,
    .redResultBox {
      width: 750px;
      height: 320px;
      position: absolute;
      left: 750px;
      top: 400px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueResultBg.png")
        no-repeat center center;
      background-size: 100%;
      animation: moveBuleBox 1s ease forwards;
      .catwin {
        top: 5px;
        left: 0;
        position: absolute;
        width: 264px;
        height: 289px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueWinIcon.png")
          no-repeat center center;
        background-size: 100%;
      }
      .catnowin {
        top: 5px;
        left: 0;
        position: absolute;
        width: 264px;
        height: 289px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/bluenoWinIcon.png")
          no-repeat center center;
        background-size: 100%;
      }
      .fishNumber {
        position: relative;
        top: 65px;

        left: 80px;
        height: 96px;
        font-size: 130px;
        font-family: Arial Rounded MT;
        font-weight: bold;
        color: rgba(255, 227, 73, 1);
        -webkit-text-stroke: 6px rgba(25, 54, 119, 1);
        text-stroke: 6px rgba(25, 54, 119, 1);

        background: linear-gradient(
          0deg,
          rgba(255, 241, 167, 1) 0%,
          rgba(255, 227, 73, 1) 99.31640625%
        );
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .Result {
        position: relative;
        top: 44px;
        left: 220px;
        width: 108px;
        height: 108px;
        display: inline-block;
      }
      .win {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueWin.png")
          no-repeat center center;
        background-size: 100%;
      }
      .fu {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/bluenegative.png")
          no-repeat center center;
        background-size: 100%;
      }
      .ping {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/nowin.png")
          no-repeat center center;
        background-size: 100%;
      }
    }

    @keyframes moveBuleBox {
      0% {
        left: 750px;
      }
      100% {
        left: 0;
      }
    }
    @keyframes moveRedBox {
      0% {
        left: -750px;
      }
      100% {
        left: 0;
      }
    }
    .redResultBox {
      left: -750px;
      top: 624px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/redResultBg.png")
        no-repeat center center;
      background-size: 100%;
      animation: moveRedBox 1s ease forwards;
      .catwin {
        top: -45px;
        left: 450px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/redWinIcon.png")
          no-repeat center center;
        background-size: 100%;
      }
      .catnowin {
        top: -45px;
        left: 450px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/rednoWinIcon.png")
          no-repeat center center;
        background-size: 100%;
      }
      .fishNumber {
        height: 94px;
        top: 94px;
        font-size: 130px;
        font-family: Arial Rounded MT;
        font-weight: bold;
        color: rgba(73, 223, 255, 1);
        -webkit-text-stroke: 6px rgba(99, 13, 17, 1);
        text-stroke: 6px rgba(99, 13, 17, 1);

        background: linear-gradient(
          0deg,
          rgba(181, 242, 255, 1) 0%,
          rgba(73, 223, 255, 1) 99.31640625%
        );
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }
      .Result {
        position: relative;
        left: -300px;
        top: 124px;
      }
      .win {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/redWin.png")
          no-repeat center center;
        background-size: 100%;
      }
      .fu {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/rednegative.png")
          no-repeat center center;
        background-size: 100%;
      }

      .ping {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/nowin.png")
          no-repeat center center;
        background-size: 100%;
      }
    }
  }
  .footerBox {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 750px;
    height: 125px;
    box-sizing: border-box;
    //  border: 6px solid transparent;
    border-bottom: none;
    // border-radius: 24px 24px 0 0;
    z-index: 200;

    background: url("https://coscdn.suresvip.com/app/html/images/Fish/fixedBg.png")
      no-repeat center center;
    background-size: 100%;
    .RecodeBox {
      position: absolute;
      left: 0;
      width: 170px;
      height: 235px;
      top: -228px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/RecordBg.png")
        no-repeat center center;
      background-size: 100%;
      z-index: 10;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-content: flex-start;
      align-items: flex-start;
      li {
        width: 100%;
        box-sizing: border-box;
        padding-left: 12px;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        height: 76px;
        img {
          width: 61px;
          height: 61px;
        }
        span {
          // height: 19px;
          font-size: 24px;
          font-family: PingFang SC;
          font-weight: 800;
          color: rgba(159, 97, 36, 1);
        }
      }
    }
    .stakeBtn {
      position: absolute;
      right: 0;
      top: -74px;
      width: 170px;
      border: none;
      height: 75px;
    }
    .stakeclose {
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/stateBtn.png")
        no-repeat center center;
      background-size: 100%;
    }
    .stakeopen {
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/RetractBtn.png")
        no-repeat center center;
      background-size: 100%;
    }
    .footerContent {
      width: 92%;
      height: 80px;
      margin: 0 auto;
      display: flex;
      flex-direction: row;
      padding-top: 6px;
      position: absolute;
      bottom: 16px;
      left: 50%;
      transform: translateX(-50%);
      justify-content: space-around;
      align-content: center;
      align-items: center;
      .info_Content {
        width: 55%;
        height: 100%;
        margin-left: 75px;
        // border:1px solid #f00;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
        align-content: center;
        .catName {
          // width:71px;
          height: 24px;
          font-size: 24px;
          font-family: Source Han Sans CN;
          font-weight: bold;
          color: rgba(255, 255, 255, 1);
          text-shadow: 0px 1px 1px rgba(100, 117, 121, 1);
        }
        .catNumber {
          width: 100%;
          height: 20px;
          font-size: 18px;
          text-align: left;
          font-family: Source Han Sans CN;
          font-weight: bold;
          color: rgba(255, 255, 255, 1);
          text-shadow: 0px 1px 1px rgba(100, 117, 121, 1);
        }
      }
    }
    li.info {
      width: 209px;
      height: 80px;
      .infoContent {
        width: 100%;
        height: 100%;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueWinBg.png")
          no-repeat center center;
        background-size: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border-radius: 45px;
        // border: 1px solid #f00;
        .pingdraw {
          width: 100%;
          height: 28px;
          font-size: 24px;
          text-align: center;
          font-family: Microsoft YaHei;
          font-weight: 400;
          color: rgba(21, 37, 95, 1);
        }
        .pingNumber {
          width: 100%;
          height: 42px;
          font-size: 34px;
          font-family: Arial Rounded MT;
          font-weight: bold;
          color: rgba(255, 255, 255, 1);
        }
      }
    }
    li.red {
      .infoContent {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/redWinBg.png")
          no-repeat center center;
        background-size: 100%;
      }
    }
    li.info2 {
      width: 186px;
      height: 80px;
      .infoContent {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/flatWinBg.png")
          no-repeat center center;
        background-size: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        align-content: center;
        .pingdraw {
          width: 100%;
          height: 22px;
          font-size: 24px;
          font-family: Source Han Sans CN;
          font-weight: bold;
          color: rgba(255, 255, 255, 1);
          text-shadow: 0px 1px 1px rgba(222, 111, 40, 1);
        }
        .pingNumber {
          width: 100%;
          height: 24px;
          font-size: 18px;
          font-family: Source Han Sans CN;
          font-weight: bold;
          color: rgba(255, 255, 255, 1);
          text-shadow: 0px 1px 1px rgba(222, 111, 40, 1);
        }
      }
    }
  }
  .stakeOpen {
    width: 750px;
    height: 369px;
    background: url("https://coscdn.suresvip.com/app/html/images/Fish/stakeOpenbg.png")
      no-repeat center center;
    background-size: 100%;
    .stakeBox {
      width: 90%;
      height: 228px;
      display: flex;
      flex-direction: row;
      justify-content: space-around;
      flex-wrap: wrap;
      align-items: center;
      align-content: space-between;
      margin: 28px auto 0;
      ul {
        flex: 1;
        height: 248px;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
        align-items: center;
        align-content: space-between;
      }
      li {
        width: 206px;
        height: 66px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/betBg.png")
          no-repeat center center;
        background-size: 100%;
        // margin:8px 9px;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        padding-left: 27px;
        box-sizing: border-box;
        font-size: 24px;
        font-family: PingFang SC;
        font-weight: bold;
        color: rgba(159, 97, 36, 1);
        img {
          width: 32px;
          height: 26px;
          margin-right: 9px;
        }
        .Multiple {
          margin-left: 6px;
          height: 24px;
          font-size: 16px;
          font-family: PingFang SC;
          font-weight: bold;
          color: rgba(159, 97, 36, 1);
        }
      }
    }
  }
  .skyBox {
    position: absolute;
    top: 0;
    z-index: 1;
    width: 750px;
    height: 722px;
    background: url("https://coscdn.suresvip.com/app/html/images/Fish/sky.png")
      no-repeat center center;
    background-size: 100%;
    header {
      width: 750px;
      height: 136px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/headBg.png")
        no-repeat center center;
      background-size: 100% 100%;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      align-content: center;
      .headerContent {
        width: 690px;
        height: 90px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        align-content: center;
        .headInfoBox {
          display: flex;
          flex-direction: row;
          justify-content: flex-start;
          align-items: center;
          align-content: center;
          .infoBox {
            margin-left: 15px;
            .userName {
              text-align: left;
              width: 300px;
              overflow: hidden; //超出的文本隐藏
              text-overflow: ellipsis; //溢出用省略号显示
              white-space: nowrap; //溢出不换行
              height: 42px;
              font-size: 29px;
              font-family: PingFang SC;
              font-weight: 500;
              color: rgba(255, 255, 255, 1);
            }
            .moneyBox {
              width: 194px;
              height: 35px;
              background: url("https://coscdn.suresvip.com/app/html/images/Fish/headerInfoBg.png")
                no-repeat center center;
              background-size: 100%;
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              align-items: center;
              line-height: 35px;
              align-content: center;
              .leftBox {
                font-size: 24px;
                font-family: PingFang SC;
                font-weight: 500;
                color: rgba(255, 255, 255, 1);
                width: 132px;
                display: flex;
                justify-content: flex-start;
                align-items: center;
                img {
                  width: 32px;
                  height: 26px;
                  margin-left: 10px;
                  vertical-align: middle;
                }
              }
              .rechargeIcon {
                width: 30px;
                height: 30px;
              }
            }
          }
        }
        .headBox {
          width: 90px;
          height: 90px;
          border-radius: 50%;
          // background: #000;
          // border: 1px solid #f00;
        }
        button {
          width: 87px;
          height: 70px;
          border: none;
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/Recordicon.png")
            no-repeat center center;
          background-size: 100%;
        }
        .ruleBtn {
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/ruleicon.png")
            no-repeat center center;
          background-size: 100%;
        }
      }
    }
    .trendBox {
      width: 534px;
      height: 90px;
      position: absolute;
      left: 50%;
      top: 170px;
      transform: translateX(-50%);
      // border: 1px solid #f00;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-content: center;
      align-items: center;
      .trendCatBox {
        width: 434px;
        height: 45px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/catBg.png")
          no-repeat center center;
        background-size: 100%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        align-content: center;
        li {
          width: 36px;
          height: 30px;
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueCatIcon.png")
            no-repeat center center;
          background-size: 100%;
          margin: 1px auto;
          flex-shrink: 0;
        }
        li.red {
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/redCatIcon.png")
            no-repeat center center;
          background-size: 100%;
        }
        li.flat {
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/flatCatIcon.png")
            no-repeat center center;
          background-size: 100%;
        }
        li:last-child {
          margin-left: 4px;
          width: 11px;
          height: 19px;
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/rightIcon.png")
            no-repeat center center;
          background-size: 100%;
        }
      }
    }
    .timerBox {
      width: 534px;
      height: 44px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/timerpress.png")
        no-repeat center center;
      background-size: 100%;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: flex-start;
      align-content: center;
      .timerBox {
        width: 60px;
        height: 60px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/timerBg.png")
          no-repeat center center;
        background-size: 100%;
        font-size: 36px;
        font-family: Yuanti TC;
        text-align: right;
        font-weight: bold;
        color: rgba(193, 92, 0, 1);
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        li {
          width: 37px;
          height: 30px;
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/redFish.png")
            no-repeat center center;
          background-size: 100%;
        }
        li.active {
          background: url("https://coscdn.suresvip.com/app/html/images/Fish/redFishActive.png")
            no-repeat center center;
          background-size: 100%;
        }
      }
      .leftFishBox,
      .rightFishBox {
        flex: 1;
        font-size: 24px;
        height: 44px;
        font-family: PingFang SC;
        font-weight: 800;
        color: rgba(255, 255, 255, 1);
        line-height: 40px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        .timerInfo {
          width: 100%;
          height: 100%;
        }
        .timerInfoContent {
          width: 197px;
          height: 27px;
          // border: 1px solid #f00;
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
          align-content: center;
          li {
            width: 37px;
            height: 30px;
            background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueFish.png")
              no-repeat center center;
            background-size: 100%;
          }
          li.active {
            background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueFishActive.png")
              no-repeat center center;
            background-size: 100%;
          }
        }
      }
      .rightFishBox {
        .timerInfoContent {
          li {
            width: 37px;
            height: 30px;
            background: url("https://coscdn.suresvip.com/app/html/images/Fish/redFish.png")
              no-repeat center center;
            background-size: 100%;
          }
          li.active {
            background: url("https://coscdn.suresvip.com/app/html/images/Fish/redFishActive.png")
              no-repeat center center;
            background-size: 100%;
          }
        }
      }
    }
    .leftShip {
      width: 234px;
      height: 153px;
      position: absolute;
      z-index: 5;
      left: 0;
      top: 580px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/leftShip.png")
        no-repeat center center;
      background-size: 100%;
    }
    .rightShip {
      width: 234px;
      height: 153px;
      position: absolute;
      z-index: 4;

      right: 0;
      top: 580px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/rightShip.png")
        no-repeat center center;
      background-size: 100%;
    }
    .blueCat {
      width: 524px;
      height: 550px;
      position: absolute;
      left: -5px;
      z-index: 100;
      top: 200px;
      // background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueCat.png") no-repeat
      //   center center;
      // background-size: 100%;
      canvas {
        width: calc(524 / 2) px;
        height: calc(550 / 2) px;
        transform: scale(0.5) translate(-50%, -50%);
      }
    }
    .redCat {
      width: 524px;
      height: 550px;
      position: absolute;
      right: -5px;
      top: 200px;
      z-index: 100;
      // background: url("https://coscdn.suresvip.com/app/html/images/Fish/redCat.png") no-repeat
      //   center center;
      // background-size: 100%;
      canvas {
        width: calc(524 / 2) px;
        height: calc(550 / 2) px;
        transform: scale(0.5) translate(-50%, -50%);
      }
    }
  }
  .seaBox {
    position: absolute;
    top: 638px;
    z-index: 10;
    // top: 0px;
    width: 750px;
    height: 704px;
    // background: url("https://coscdn.suresvip.com/app/html/images/Fish/sea.png") no-repeat center
    //   center;
    // background-size: 100%;
    .seaComp {
      width: 100%;
      height: 100%;
      canvas{
         width: calc(750 / 2) px;
        height: calc(704 / 2) px;
        transform: scale(0.5) translate(-50%, -50%);
      }
    }
    .bettingDetails {
      position: absolute;
      width: 700px;
      height: 384px;
      background: url("https://coscdn.suresvip.com/app/html/images/Fish/bettingDetails.png")
        no-repeat center center;
      background-size: 100%;
      top: 100px;
      left: 50%;
      transform: translateX(-50%);
      box-sizing: border-box;
      padding: 10px 12px;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      align-content: center;
      overflow-y: scroll;

      .betting {
        width: 216px;
        height: 364px;
        // border: 1px solid #f00;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-content: center;
        align-items: center;

        padding-top: 5px;
        // li {
        //   width: 76%;
        //   height: 58px;
        //   border: 1px solid #f00;
        //   flex-shrink: 0;
        // }
        .betting_content {
          width: 72%;
          height: 274px;
          overflow-y: scroll;
          li {
            width: 100%;
            height: 60px;
            // border: 1px solid #f00;
            box-sizing: border-box;
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            .headBox {
              width: 36px;
              height: 36px;
              border-radius: 50%;
              background: #fff;
              margin-right: 8px;
            }
            span {
              color: #fff;
              font-size: 22px;
              font-family: Source Han Sans CN;
              font-weight: bold;
              color: rgba(255, 255, 255, 1);
            }
          }
          li:nth-child(1) {
            border-bottom: 1px dotted #fff;
          }
        }
        .betting_top {
          width: 100%;
          height: 75px;
          // border: 1px solid #f00;
          display: flex;
          flex-direction: column;
          justify-content: center;
          .userCat {
            font-size: 24px;
            font-family: Source Han Sans CN;

            font-weight: bold;
            color: rgba(255, 255, 255, 1);
            text-shadow: 0px 1px 1px rgba(100, 117, 121, 1);
          }
          .userNumber {
            height: 24px;
            font-size: 18px;
            font-family: Source Han Sans CN;
            font-weight: bold;
            color: rgba(255, 255, 255, 1);
            text-shadow: 0px 1px 1px rgba(100, 117, 121, 1);
          }
        }
      }
      .blueBettingBox {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/blueBettingBoxBg.png")
          no-repeat center center;
        background-size: 100%;
        order:0;
      }
      .flatBettingBox {
        width: 196px;
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/flatBettingBoxBg.png")
          no-repeat center center;
        background-size: 100%;
        order: 1;
      }
      .redBettingBox {
        background: url("https://coscdn.suresvip.com/app/html/images/Fish/redBettingBoxBg.png")
          no-repeat center center;
        background-size: 100%;
        order: 2;
      }
    }
    .seaInfo {
      position: absolute;
      left: 50%;
      top: 108px;
      transform: translateX(-50%);
      width: 384px;
      height: 69px;
      font-size: 30px;
      font-family: PingFang SC;
      font-weight: 800;
      color: rgba(255, 255, 255, 1);
      line-height: 40px;
      text-shadow: 0px 1px 3px rgba(28, 147, 222, 0.75);
    }
  }
}
</style>